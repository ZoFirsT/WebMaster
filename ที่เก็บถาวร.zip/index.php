<!DOCTYPE html>
<html lang="en-US">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">

    <title>KhongLao</title>
    <meta name='robots' content='noindex, nofollow' />
    <link rel='dns-prefetch' href='//fonts.googleapis.com' />
    <link rel="alternate" type="application/rss+xml" title="Astra &raquo; Feed" href="#?feed=rss2" />
    <link rel="alternate" type="application/rss+xml" title="Astra &raquo; Comments Feed" href="#?feed=comments-rss2" />
    <link rel="alternate" type="application/rss+xml" title="Astra &raquo; Home Comments Feed"
        href="#?feed=rss2&#038;page_id=10000" />
    <style>
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 0.07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <link rel='stylesheet' id='astra-theme-css-css'
        href='https://wp-themes.com/wp-content/themes/astra/assets/css/minified/main.min.css?ver=4.0.2' media='all' />
    <style id='astra-theme-css-inline-css'>
        @import url('https://fonts.googleapis.com/css2?family=Sono&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=Prompt&display=swap');

        * {
            font-family: 'Sono', sans-serif;
        }


        :root {
            --ast-container-default-xlg-padding: 3em;
            --ast-container-default-lg-padding: 3em;
            --ast-container-default-slg-padding: 2em;
            --ast-container-default-md-padding: 3em;
            --ast-container-default-sm-padding: 3em;
            --ast-container-default-xs-padding: 2.4em;
            --ast-container-default-xxs-padding: 1.8em;
            --ast-code-block-background: #ECEFF3;
            --ast-comment-inputs-background: #F9FAFB;
        }

        html {
            font-size: 112.5%;
        }

        a {
            color: var(--ast-global-color-0);
        }

        a:hover,
        a:focus {
            color: var(--ast-global-color-1);
        }

        body,
        button,
        input,
        select,
        textarea,
        .ast-button,
        .ast-custom-button {
            font-family: 'Inter', sans-serif;
            font-weight: inherit;
            font-size: 18px;
            font-size: 1rem;
        }

        blockquote {
            color: var(--ast-global-color-3);
        }

        h1,
        .entry-content h1,
        h2,
        .entry-content h2,
        h3,
        .entry-content h3,
        h4,
        .entry-content h4,
        h5,
        .entry-content h5,
        h6,
        .entry-content h6,
        .site-title,
        .site-title a {
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-weight: 600;
        }

        .site-title {
            font-size: 35px;
            font-size: 1.9444444444444rem;
            display: none;
        }

        .site-header .site-description {
            font-size: 15px;
            font-size: 0.83333333333333rem;
            display: none;
        }

        .entry-title {
            font-size: 30px;
            font-size: 1.6666666666667rem;
        }

        h1,
        .entry-content h1 {
            font-size: 64px;
            font-size: 3.5555555555556rem;
            font-weight: 600;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        h2,
        .entry-content h2 {
            font-size: 48px;
            font-size: 2.6666666666667rem;
            font-weight: 600;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        h3,
        .entry-content h3 {
            font-size: 24px;
            font-size: 1.3333333333333rem;
            font-weight: 600;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        h4,
        .entry-content h4 {
            font-size: 20px;
            font-size: 1.1111111111111rem;
            font-weight: 600;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        h5,
        .entry-content h5 {
            font-size: 18px;
            font-size: 1rem;
            font-weight: 600;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        h6,
        .entry-content h6 {
            font-size: 15px;
            font-size: 0.83333333333333rem;
            font-weight: 600;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        ::selection {
            background-color: var(--ast-global-color-0);
            color: #ffffff;
        }

        body,
        h1,
        .entry-title a,
        .entry-content h1,
        h2,
        .entry-content h2,
        h3,
        .entry-content h3,
        h4,
        .entry-content h4,
        h5,
        .entry-content h5,
        h6,
        .entry-content h6 {
            color: var(--ast-global-color-3);
        }

        .tagcloud a:hover,
        .tagcloud a:focus,
        .tagcloud a.current-item {
            color: #ffffff;
            border-color: var(--ast-global-color-0);
            background-color: var(--ast-global-color-0);
        }

        input:focus,
        input[type="text"]:focus,
        input[type="email"]:focus,
        input[type="url"]:focus,
        input[type="password"]:focus,
        input[type="reset"]:focus,
        input[type="search"]:focus,
        textarea:focus {
            border-color: var(--ast-global-color-0);
        }

        input[type="radio"]:checked,
        input[type=reset],
        input[type="checkbox"]:checked,
        input[type="checkbox"]:hover:checked,
        input[type="checkbox"]:focus:checked,
        input[type=range]::-webkit-slider-thumb {
            border-color: var(--ast-global-color-0);
            background-color: var(--ast-global-color-0);
            box-shadow: none;
        }

        .site-footer a:hover+.post-count,
        .site-footer a:focus+.post-count {
            background: var(--ast-global-color-0);
            border-color: var(--ast-global-color-0);
        }

        .single .nav-links .nav-previous,
        .single .nav-links .nav-next {
            color: var(--ast-global-color-0);
        }

        .entry-meta,
        .entry-meta * {
            line-height: 1.45;
            color: var(--ast-global-color-0);
        }

        .entry-meta a:hover,
        .entry-meta a:hover *,
        .entry-meta a:focus,
        .entry-meta a:focus *,
        .page-links>.page-link,
        .page-links .page-link:hover,
        .post-navigation a:hover {
            color: var(--ast-global-color-1);
        }

        #cat option,
        .secondary .calendar_wrap thead a,
        .secondary .calendar_wrap thead a:visited {
            color: var(--ast-global-color-0);
        }

        .secondary .calendar_wrap #today,
        .ast-progress-val span {
            background: var(--ast-global-color-0);
        }

        .secondary a:hover+.post-count,
        .secondary a:focus+.post-count {
            background: var(--ast-global-color-0);
            border-color: var(--ast-global-color-0);
        }

        .calendar_wrap #today>a {
            color: #ffffff;
        }

        .page-links .page-link,
        .single .post-navigation a {
            color: var(--ast-global-color-0);
        }

        .ast-archive-title {
            color: var(--ast-global-color-2);
        }

        .widget-title {
            font-size: 25px;
            font-size: 1.3888888888889rem;
            color: var(--ast-global-color-2);
        }

        .ast-single-post .entry-content a,
        .ast-comment-content a:not(.ast-comment-edit-reply-wrap a) {
            text-decoration: underline;
        }

        .ast-single-post .wp-block-button .wp-block-button__link,
        .ast-single-post .elementor-button-wrapper .elementor-button,
        .ast-single-post .entry-content .uagb-tab a,
        .ast-single-post .entry-content .uagb-ifb-cta a,
        .ast-single-post .entry-content .wp-block-uagb-buttons a,
        .ast-single-post .entry-content .uabb-module-content a,
        .ast-single-post .entry-content .uagb-post-grid a,
        .ast-single-post .entry-content .uagb-timeline a,
        .ast-single-post .entry-content .uagb-toc__wrap a,
        .ast-single-post .entry-content .uagb-taxomony-box a,
        .ast-single-post .entry-content .woocommerce a,
        .entry-content .wp-block-latest-posts>li>a,
        .ast-single-post .entry-content .wp-block-file__button {
            text-decoration: none;
        }

        .site-logo-img img {
            transition: all 0.2s linear;
        }

        @media (max-width: 921px) {
            #ast-desktop-header {
                display: none;
            }
        }

        @media (min-width: 921px) {
            #ast-mobile-header {
                display: none;
            }
        }

        .wp-block-buttons.aligncenter {
            justify-content: center;
        }

        @media (max-width: 921px) {

            .ast-theme-transparent-header #primary,
            .ast-theme-transparent-header #secondary {
                padding: 0;
            }
        }

        @media (max-width: 921px) {
            .ast-plain-container.ast-no-sidebar #primary {
                padding: 0;
            }
        }

        .ast-plain-container.ast-no-sidebar #primary {
            margin-top: 0;
            margin-bottom: 0;
        }

        .wp-block-button.is-style-outline .wp-block-button__link {
            border-color: var(--ast-global-color-7);
        }

        .wp-block-button.is-style-outline>.wp-block-button__link:not(.has-text-color),
        .wp-block-button.wp-block-button__link.is-style-outline:not(.has-text-color) {
            color: var(--ast-global-color-7);
        }

        .wp-block-button.is-style-outline .wp-block-button__link:hover,
        .wp-block-button.is-style-outline .wp-block-button__link:focus {
            color: var(--ast-global-color-2) !important;
            background-color: var(--ast-global-color-7);
            border-color: var(--ast-global-color-7);
        }

        .post-page-numbers.current .page-link,
        .ast-pagination .page-numbers.current {
            color: #ffffff;
            border-color: var(--ast-global-color-0);
            background-color: var(--ast-global-color-0);
            border-radius: 2px;
        }

        h1.widget-title {
            font-weight: 600;
        }

        h2.widget-title {
            font-weight: 600;
        }

        h3.widget-title {
            font-weight: 600;
        }

        #page {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .ast-404-layout-1 h1.page-title {
            color: var(--ast-global-color-2);
        }

        .single .post-navigation a {
            line-height: 1em;
            height: inherit;
        }

        .error-404 .page-sub-title {
            font-size: 1.5rem;
            font-weight: inherit;
        }

        .search .site-content .content-area .search-form {
            margin-bottom: 0;
        }

        #page .site-content {
            flex-grow: 1;
        }

        .widget {
            margin-bottom: 3.5em;
        }

        #secondary li {
            line-height: 1.5em;
        }

        #secondary .wp-block-group h2 {
            margin-bottom: 0.7em;
        }

        #secondary h2 {
            font-size: 1.7rem;
        }

        .ast-separate-container .ast-article-post,
        .ast-separate-container .ast-article-single,
        .ast-separate-container .ast-comment-list li.depth-1,
        .ast-separate-container .comment-respond {
            padding: 3em;
        }

        .ast-separate-container .ast-comment-list li.depth-1,
        .hentry {
            margin-bottom: 2em;
        }

        .ast-separate-container .ast-archive-description,
        .ast-separate-container .ast-author-box {
            background-color: var(--ast-global-color-5);
            border-bottom: 1px solid var(--ast-border-color);
        }

        .ast-separate-container .comments-title {
            padding: 2em 2em 0 2em;
        }

        .ast-page-builder-template .comment-form-textarea,
        .ast-comment-formwrap .ast-grid-common-col {
            padding: 0;
        }

        .ast-comment-formwrap {
            padding: 0 20px;
            display: inline-flex;
            column-gap: 20px;
        }

        .archive.ast-page-builder-template .entry-header {
            margin-top: 2em;
        }

        .ast-page-builder-template .ast-comment-formwrap {
            width: 100%;
        }

        .entry-title {
            margin-bottom: 0.5em;
        }

        .ast-archive-description p {
            font-size: inherit;
            font-weight: inherit;
            line-height: inherit;
        }

        @media (min-width: 921px) {

            .ast-left-sidebar.ast-page-builder-template #secondary,
            .archive.ast-right-sidebar.ast-page-builder-template .site-main {
                padding-left: 20px;
                padding-right: 20px;
            }
        }

        @media (max-width: 544px) {
            .ast-comment-formwrap.ast-row {
                column-gap: 10px;
                display: inline-block;
            }

            #ast-commentform .ast-grid-common-col {
                position: relative;
                width: 100%;
            }
        }

        @media (min-width: 1201px) {

            .ast-separate-container .ast-article-post,
            .ast-separate-container .ast-article-single,
            .ast-separate-container .ast-author-box,
            .ast-separate-container .ast-404-layout-1,
            .ast-separate-container .no-results {
                padding: 3em;
            }
        }

        @media (max-width: 921px) {

            .ast-separate-container #primary,
            .ast-separate-container #secondary {
                padding: 1.5em 0;
            }

            #primary,
            #secondary {
                padding: 1.5em 0;
                margin: 0;
            }

            .ast-left-sidebar #content>.ast-container {
                display: flex;
                flex-direction: column-reverse;
                width: 100%;
            }
        }

        @media (min-width: 922px) {

            .ast-separate-container.ast-right-sidebar #primary,
            .ast-separate-container.ast-left-sidebar #primary {
                border: 0;
            }

            .search-no-results.ast-separate-container #primary {
                margin-bottom: 4em;
            }
        }

        .wp-block-button .wp-block-button__link {
            color: var(--ast-global-color-2);
        }

        .wp-block-button .wp-block-button__link:hover,
        .wp-block-button .wp-block-button__link:focus {
            color: var(--ast-global-color-2);
            background-color: var(--ast-global-color-7);
            border-color: var(--ast-global-color-7);
        }

        .wp-block-button .wp-block-button__link,
        .wp-block-search .wp-block-search__button,
        body .wp-block-file .wp-block-file__button {
            border-style: solid;
            border-top-width: 0px;
            border-right-width: 0px;
            border-left-width: 0px;
            border-bottom-width: 0px;
            border-color: var(--ast-global-color-7);
            background-color: var(--ast-global-color-7);
            color: var(--ast-global-color-2);
            font-family: inherit;
            font-weight: 600;
            font-size: 20px;
            font-size: 1.1111111111111rem;
            border-radius: 50px;
            padding-top: 20px;
            padding-right: 40px;
            padding-bottom: 20px;
            padding-left: 40px;
        }

        @media (max-width: 921px) {

            .wp-block-button .wp-block-button__link,
            .wp-block-search .wp-block-search__button,
            body .wp-block-file .wp-block-file__button {
                padding-top: 18px;
                padding-right: 32px;
                padding-bottom: 18px;
                padding-left: 32px;
            }
        }

        @media (max-width: 544px) {

            .wp-block-button .wp-block-button__link,
            .wp-block-search .wp-block-search__button,
            body .wp-block-file .wp-block-file__button {
                padding-top: 15px;
                padding-right: 28px;
                padding-bottom: 15px;
                padding-left: 28px;
            }
        }



        @media (min-width: 544px) {
            .ast-container {
                max-width: 100%;
            }
        }

        @media (max-width: 544px) {

            .ast-separate-container .ast-article-post,
            .ast-separate-container .ast-article-single,
            .ast-separate-container .comments-title,
            .ast-separate-container .ast-archive-description {
                padding: 1.5em 1em;
            }

            .ast-separate-container #content .ast-container {
                padding-left: 0.54em;
                padding-right: 0.54em;
            }

            .ast-separate-container .ast-comment-list li.depth-1 {
                padding: 1.5em 1em;
                margin-bottom: 1.5em;
            }

            .ast-separate-container .ast-comment-list .bypostauthor {
                padding: .5em;
            }

            .ast-search-menu-icon.ast-dropdown-active .search-field {
                width: 170px;
            }

            .menu-toggle,
            button,
            .ast-button,
            .button,
            input#submit,
            input[type="button"],
            input[type="submit"],
            input[type="reset"] {
                padding-top: 15px;
                padding-right: 28px;
                padding-bottom: 15px;
                padding-left: 28px;
            }
        }

        @media (max-width: 921px) {

            .menu-toggle,
            button,
            .ast-button,
            .button,
            input#submit,
            input[type="button"],
            input[type="submit"],
            input[type="reset"] {
                padding-top: 18px;
                padding-right: 32px;
                padding-bottom: 18px;
                padding-left: 32px;
            }

            .ast-mobile-header-stack .main-header-bar .ast-search-menu-icon {
                display: inline-block;
            }

            .ast-header-break-point.ast-header-custom-item-outside .ast-mobile-header-stack .main-header-bar .ast-search-icon {
                margin: 0;
            }

            .ast-comment-avatar-wrap img {
                max-width: 2.5em;
            }

            .ast-separate-container .ast-comment-list li.depth-1 {
                padding: 1.5em 2.14em;
            }

            .ast-separate-container .comment-respond {
                padding: 2em 2.14em;
            }

            .ast-comment-meta {
                padding: 0 1.8888em 1.3333em;
            }
        }

        @media (max-width: 921px) {
            .site-title {
                display: none;
            }

            .site-header .site-description {
                display: none;
            }

            .entry-title {
                font-size: 30px;
            }

            h1,
            .entry-content h1 {
                font-size: 30px;
            }

            h2,
            .entry-content h2 {
                font-size: 25px;
            }

            h3,
            .entry-content h3 {
                font-size: 20px;
            }
        }

        @media (max-width: 544px) {
            .site-title {
                display: none;
            }

            .site-header .site-description {
                display: none;
            }

            .entry-title {
                font-size: 30px;
            }

            h1,
            .entry-content h1 {
                font-size: 30px;
            }

            h2,
            .entry-content h2 {
                font-size: 25px;
            }

            h3,
            .entry-content h3 {
                font-size: 20px;
            }
        }

        @media (max-width: 921px) {
            html {
                font-size: 102.6%;
            }
        }

        @media (max-width: 544px) {
            html {
                font-size: 102.6%;
            }
        }

        @media (min-width: 922px) {
            .ast-container {
                max-width: 1240px;
            }
        }

        @media (min-width: 922px) {
            .site-content .ast-container {
                display: flex;
            }
        }

        @media (max-width: 921px) {
            .site-content .ast-container {
                flex-direction: column;
            }
        }

        @media (min-width: 922px) {

            .main-header-menu .sub-menu .menu-item.ast-left-align-sub-menu:hover>.sub-menu,
            .main-header-menu .sub-menu .menu-item.ast-left-align-sub-menu.focus>.sub-menu {
                margin-left: -0px;
            }
        }

        .ast-theme-transparent-header [data-section="section-header-mobile-trigger"] .ast-button-wrap .ast-mobile-menu-trigger-minimal {
            background: transparent;
        }

        blockquote,
        cite {
            font-style: initial;
        }

        .wp-block-file {
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            justify-content: space-between;
        }

        .wp-block-pullquote {
            border: none;
        }

        .wp-block-pullquote blockquote::before {
            content: "\201D";
            font-family: "Helvetica", sans-serif;
            display: flex;
            transform: rotate(180deg);
            font-size: 6rem;
            font-style: normal;
            line-height: 1;
            font-weight: bold;
            align-items: center;
            justify-content: center;
        }

        .has-text-align-right>blockquote::before {
            justify-content: flex-start;
        }

        .has-text-align-left>blockquote::before {
            justify-content: flex-end;
        }

        figure.wp-block-pullquote.is-style-solid-color blockquote {
            max-width: 100%;
            text-align: inherit;
        }

        html body {
            --wp--custom--ast-default-block-top-padding: 100px;
            --wp--custom--ast-default-block-right-padding: 80px;
            --wp--custom--ast-default-block-bottom-padding: 100px;
            --wp--custom--ast-default-block-left-padding: 80px;
            --wp--custom--ast-container-width: 1200px;
            --wp--custom--ast-content-width-size: 1200px;
            --wp--custom--ast-wide-width-size: calc(1200px + var(--wp--custom--ast-default-block-left-padding) + var(--wp--custom--ast-default-block-right-padding));
        }

        .ast-narrow-container {
            --wp--custom--ast-content-width-size: 750px;
            --wp--custom--ast-wide-width-size: 750px;
        }

        @media (max-width: 921px) {
            html body {
                --wp--custom--ast-default-block-top-padding: 50px;
                --wp--custom--ast-default-block-right-padding: 50px;
                --wp--custom--ast-default-block-bottom-padding: 50px;
                --wp--custom--ast-default-block-left-padding: 50px;
            }
        }

        @media (max-width: 544px) {
            html body {
                --wp--custom--ast-default-block-top-padding: 50px;
                --wp--custom--ast-default-block-right-padding: 30px;
                --wp--custom--ast-default-block-bottom-padding: 50px;
                --wp--custom--ast-default-block-left-padding: 30px;
            }
        }

        .entry-content>.wp-block-group,
        .entry-content>.wp-block-cover,
        .entry-content>.wp-block-columns {
            padding-top: var(--wp--custom--ast-default-block-top-padding);
            padding-right: var(--wp--custom--ast-default-block-right-padding);
            padding-bottom: var(--wp--custom--ast-default-block-bottom-padding);
            padding-left: var(--wp--custom--ast-default-block-left-padding);
        }

        .ast-plain-container.ast-no-sidebar .entry-content>.alignfull,
        .ast-page-builder-template .ast-no-sidebar .entry-content>.alignfull {
            margin-left: calc(-50vw + 50%);
            margin-right: calc(-50vw + 50%);
            max-width: 100vw;
            width: 100vw;
        }

        .ast-plain-container.ast-no-sidebar .entry-content .alignfull .alignfull,
        .ast-page-builder-template.ast-no-sidebar .entry-content .alignfull .alignfull,
        .ast-plain-container.ast-no-sidebar .entry-content .alignfull .alignwide,
        .ast-page-builder-template.ast-no-sidebar .entry-content .alignfull .alignwide,
        .ast-plain-container.ast-no-sidebar .entry-content .alignwide .alignfull,
        .ast-page-builder-template.ast-no-sidebar .entry-content .alignwide .alignfull,
        .ast-plain-container.ast-no-sidebar .entry-content .alignwide .alignwide,
        .ast-page-builder-template.ast-no-sidebar .entry-content .alignwide .alignwide,
        .ast-plain-container.ast-no-sidebar .entry-content .wp-block-column .alignfull,
        .ast-page-builder-template.ast-no-sidebar .entry-content .wp-block-column .alignfull,
        .ast-plain-container.ast-no-sidebar .entry-content .wp-block-column .alignwide,
        .ast-page-builder-template.ast-no-sidebar .entry-content .wp-block-column .alignwide {
            margin-left: auto;
            margin-right: auto;
            width: 100%;
        }

        [ast-blocks-layout] .wp-block-separator:not(.is-style-dots) {
            height: 0;
        }

        [ast-blocks-layout] .wp-block-separator {
            margin: 20px auto;
        }

        [ast-blocks-layout] .wp-block-separator:not(.is-style-wide):not(.is-style-dots) {
            max-width: 100px;
        }

        [ast-blocks-layout] .wp-block-separator.has-background {
            padding: 0;
        }

        .entry-content[ast-blocks-layout]>* {
            max-width: var(--wp--custom--ast-content-width-size);
            margin-left: auto;
            margin-right: auto;
        }

        .entry-content[ast-blocks-layout]>.alignwide {
            max-width: var(--wp--custom--ast-wide-width-size);
        }

        .entry-content[ast-blocks-layout] .alignfull {
            max-width: none;
        }

        .entry-content .wp-block-columns {
            margin-bottom: 0;
        }

        blockquote {
            margin: 1.5em;
            border: none;
        }

        .wp-block-quote:not(.has-text-align-right):not(.has-text-align-center) {
            border-left: 5px solid rgba(0, 0, 0, 0.05);
        }

        .has-text-align-right>blockquote,
        blockquote.has-text-align-right {
            border-right: 5px solid rgba(0, 0, 0, 0.05);
        }

        .has-text-align-left>blockquote,
        blockquote.has-text-align-left {
            border-left: 5px solid rgba(0, 0, 0, 0.05);
        }

        .wp-block-site-tagline,
        .wp-block-latest-posts .read-more {
            margin-top: 15px;
        }

        .wp-block-loginout p label {
            display: block;
        }

        .wp-block-loginout p:not(.login-remember):not(.login-submit) input {
            width: 100%;
        }

        .wp-block-loginout input:focus {
            border-color: transparent;
        }

        .wp-block-loginout input:focus {
            outline: thin dotted;
        }

        .entry-content .wp-block-media-text .wp-block-media-text__content {
            padding: 0 0 0 8%;
        }

        .entry-content .wp-block-media-text.has-media-on-the-right .wp-block-media-text__content {
            padding: 0 8% 0 0;
        }

        .entry-content .wp-block-media-text.has-background .wp-block-media-text__content {
            padding: 8%;
        }


        .wp-block-loginout .login-remember input {
            width: 1.1rem;
            height: 1.1rem;
            margin: 0 5px 4px 0;
            vertical-align: middle;
        }

        .wp-block-latest-posts>li>* :first-child,
        .wp-block-latest-posts:not(.is-grid)>li:first-child {
            margin-top: 0;
        }

        .wp-block-search__inside-wrapper .wp-block-search__input {
            padding: 0 10px;
            color: var(--ast-global-color-3);
            background: var(--ast-global-color-5);
            border-color: var(--ast-border-color);
        }

        .wp-block-latest-posts .read-more {
            margin-bottom: 1.5em;
        }

        .wp-block-search__no-button .wp-block-search__inside-wrapper .wp-block-search__input {
            padding-top: 5px;
            padding-bottom: 5px;
        }

        .wp-block-latest-posts .wp-block-latest-posts__post-date,
        .wp-block-latest-posts .wp-block-latest-posts__post-author {
            font-size: 1rem;
        }

        .wp-block-latest-posts>li>*,
        .wp-block-latest-posts:not(.is-grid)>li {
            margin-top: 12px;
            margin-bottom: 12px;
        }

        .ast-page-builder-template .entry-content[ast-blocks-layout]>*,
        .ast-page-builder-template .entry-content[ast-blocks-layout]>.alignfull>* {
            max-width: none;
        }

        .ast-page-builder-template .entry-content[ast-blocks-layout]>.alignwide>* {
            max-width: var(--wp--custom--ast-wide-width-size);
        }

        .ast-page-builder-template .entry-content[ast-blocks-layout]>.inherit-container-width>*,
        .ast-page-builder-template .entry-content[ast-blocks-layout]>*>*,
        .entry-content[ast-blocks-layout]>.wp-block-cover .wp-block-cover__inner-container {
            max-width: var(--wp--custom--ast-content-width-size);
            margin-left: auto;
            margin-right: auto;
        }

        .entry-content[ast-blocks-layout] .wp-block-cover:not(.alignleft):not(.alignright) {
            width: auto;
        }

        @media (max-width: 1200px) {

            .ast-separate-container .entry-content>.alignfull,
            .ast-separate-container .entry-content[ast-blocks-layout]>.alignwide,
            .ast-plain-container .entry-content[ast-blocks-layout]>.alignwide,
            .ast-plain-container .entry-content .alignfull {
                margin-left: calc(-1 * min(var(--ast-container-default-xlg-padding), 20px));
                margin-right: calc(-1 * min(var(--ast-container-default-xlg-padding), 20px));
            }
        }

        @media (min-width: 1201px) {
            .ast-separate-container .entry-content>.alignfull {
                margin-left: calc(-1 * var(--ast-container-default-xlg-padding));
                margin-right: calc(-1 * var(--ast-container-default-xlg-padding));
            }

            .ast-separate-container .entry-content[ast-blocks-layout]>.alignwide,
            .ast-plain-container .entry-content[ast-blocks-layout]>.alignwide {
                margin-left: calc(-1 * var(--wp--custom--ast-default-block-left-padding));
                margin-right: calc(-1 * var(--wp--custom--ast-default-block-right-padding));
            }
        }

        @media (min-width: 921px) {

            .ast-separate-container .entry-content .wp-block-group.alignwide:not(.inherit-container-width)> :where(:not(.alignleft):not(.alignright)),
            .ast-plain-container .entry-content .wp-block-group.alignwide:not(.inherit-container-width)> :where(:not(.alignleft):not(.alignright)) {
                max-width: calc(var(--wp--custom--ast-content-width-size) + 80px);
            }

            .ast-plain-container.ast-right-sidebar .entry-content[ast-blocks-layout] .alignfull,
            .ast-plain-container.ast-left-sidebar .entry-content[ast-blocks-layout] .alignfull {
                margin-left: -60px;
                margin-right: -60px;
            }
        }

        @media (min-width: 544px) {
            .entry-content>.alignleft {
                margin-right: 20px;
            }

            .entry-content>.alignright {
                margin-left: 20px;
            }
        }

        @media (max-width: 544px) {
            .wp-block-columns .wp-block-column:not(:last-child) {
                margin-bottom: 20px;
            }

            .wp-block-latest-posts {
                margin: 0;
            }
        }

        @media (max-width: 600px) {

            .entry-content .wp-block-media-text .wp-block-media-text__content,
            .entry-content .wp-block-media-text.has-media-on-the-right .wp-block-media-text__content {
                padding: 8% 0 0;
            }

            .entry-content .wp-block-media-text.has-background .wp-block-media-text__content {
                padding: 8%;
            }
        }

        .ast-separate-container .entry-content .wp-block-uagb-container {
            padding-left: 0;
        }

        .ast-page-builder-template .entry-header {
            padding-left: 0;
        }

        @media (min-width: 1201px) {
            .ast-separate-container .entry-content>.uagb-is-root-container {
                margin-left: 0;
                margin-right: 0;
            }
        }

        .ast-narrow-container .site-content .wp-block-uagb-image--align-full .wp-block-uagb-image__figure {
            max-width: 100%;
            margin-left: auto;
            margin-right: auto;
        }

        .entry-content ul,
        .entry-content ol {
            padding: revert;
            margin: revert;
        }

        :root .has-ast-global-color-0-color {
            color: var(--ast-global-color-0);
        }

        :root .has-ast-global-color-0-background-color {
            background-color: var(--ast-global-color-0);
        }

        :root .wp-block-button .has-ast-global-color-0-color {
            color: var(--ast-global-color-0);
        }

        :root .wp-block-button .has-ast-global-color-0-background-color {
            background-color: var(--ast-global-color-0);
        }

        :root .has-ast-global-color-1-color {
            color: var(--ast-global-color-1);
        }

        :root .has-ast-global-color-1-background-color {
            background-color: var(--ast-global-color-1);
        }

        :root .wp-block-button .has-ast-global-color-1-color {
            color: var(--ast-global-color-1);
        }

        :root .wp-block-button .has-ast-global-color-1-background-color {
            background-color: var(--ast-global-color-1);
        }

        :root .has-ast-global-color-2-color {
            color: var(--ast-global-color-2);
        }

        :root .has-ast-global-color-2-background-color {
            background-color: var(--ast-global-color-2);
        }

        :root .wp-block-button .has-ast-global-color-2-color {
            color: var(--ast-global-color-2);
        }

        :root .wp-block-button .has-ast-global-color-2-background-color {
            background-color: var(--ast-global-color-2);
        }

        :root .has-ast-global-color-3-color {
            color: var(--ast-global-color-3);
        }

        :root .has-ast-global-color-3-background-color {
            background-color: var(--ast-global-color-3);
        }

        :root .wp-block-button .has-ast-global-color-3-color {
            color: var(--ast-global-color-3);
        }

        :root .wp-block-button .has-ast-global-color-3-background-color {
            background-color: var(--ast-global-color-3);
        }

        :root .has-ast-global-color-4-color {
            color: var(--ast-global-color-4);
        }

        :root .has-ast-global-color-4-background-color {
            background-color: var(--ast-global-color-4);
        }

        :root .wp-block-button .has-ast-global-color-4-color {
            color: var(--ast-global-color-4);
        }

        :root .wp-block-button .has-ast-global-color-4-background-color {
            background-color: var(--ast-global-color-4);
        }

        :root .has-ast-global-color-5-color {
            color: var(--ast-global-color-5);
        }

        :root .has-ast-global-color-5-background-color {
            background-color: var(--ast-global-color-5);
        }

        :root .wp-block-button .has-ast-global-color-5-color {
            color: var(--ast-global-color-5);
        }

        :root .wp-block-button .has-ast-global-color-5-background-color {
            background-color: var(--ast-global-color-5);
        }

        :root .has-ast-global-color-6-color {
            color: var(--ast-global-color-6);
        }

        :root .has-ast-global-color-6-background-color {
            background-color: var(--ast-global-color-6);
        }

        :root .wp-block-button .has-ast-global-color-6-color {
            color: var(--ast-global-color-6);
        }

        :root .wp-block-button .has-ast-global-color-6-background-color {
            background-color: var(--ast-global-color-6);
        }

        :root .has-ast-global-color-7-color {
            color: var(--ast-global-color-7);
        }

        :root .has-ast-global-color-7-background-color {
            background-color: var(--ast-global-color-7);
        }

        :root .wp-block-button .has-ast-global-color-7-color {
            color: var(--ast-global-color-7);
        }

        :root .wp-block-button .has-ast-global-color-7-background-color {
            background-color: var(--ast-global-color-7);
        }

        :root .has-ast-global-color-8-color {
            color: var(--ast-global-color-8);
        }

        :root .has-ast-global-color-8-background-color {
            background-color: var(--ast-global-color-8);
        }

        :root .wp-block-button .has-ast-global-color-8-color {
            color: var(--ast-global-color-8);
        }

        :root .wp-block-button .has-ast-global-color-8-background-color {
            background-color: var(--ast-global-color-8);
        }

        :root {
            --ast-global-color-0: #060097;
            --ast-global-color-1: #c10fff;
            --ast-global-color-2: #1e293b;
            --ast-global-color-3: #67768e;
            --ast-global-color-4: #f9f6fe;
            --ast-global-color-5: #FFFFFF;
            --ast-global-color-6: #F2F5F7;
            --ast-global-color-7: #ffcd57;
            --ast-global-color-8: #000000;
        }

        :root {
            --ast-border-color: var(--ast-global-color-6);
        }

        .ast-single-entry-banner {
            -js-display: flex;
            display: flex;
            flex-direction: column;
            justify-content: center;
            text-align: center;
            position: relative;
            background: #eeeeee;
        }

        .ast-single-entry-banner[data-banner-layout="layout-1"] {
            max-width: 1200px;
            background: inherit;
            padding: 20px 0;
        }

        .ast-single-entry-banner[data-banner-width-type="custom"] {
            margin: 0 auto;
            width: 100%;
        }

        .ast-single-entry-banner+.site-content .entry-header {
            margin-bottom: 0;
        }

        header.entry-header .entry-title {
            font-weight: 600;
            font-size: 32px;
            font-size: 1.7777777777778rem;
        }

        header.entry-header>* :not(:last-child) {
            margin-bottom: 10px;
        }

        .ast-archive-entry-banner {
            -js-display: flex;
            display: flex;
            flex-direction: column;
            justify-content: center;
            text-align: center;
            position: relative;
            background: #eeeeee;
        }

        .ast-archive-entry-banner[data-banner-width-type="custom"] {
            margin: 0 auto;
            width: 100%;
        }

        .ast-archive-entry-banner[data-banner-layout="layout-1"] {
            background: inherit;
            padding: 20px 0;
            text-align: left;
        }

        body.archive .ast-archive-description {
            max-width: 1200px;
            width: 100%;
            text-align: left;
            padding-top: 3em;
            padding-right: 3em;
            padding-bottom: 3em;
            padding-left: 3em;
        }

        body.archive .ast-archive-description .ast-archive-title,
        body.archive .ast-archive-description .ast-archive-title * {
            font-weight: 600;
            font-size: 32px;
            font-size: 1.7777777777778rem;
        }

        body.archive .ast-archive-description>* :not(:last-child) {
            margin-bottom: 10px;
        }

        @media (max-width: 921px) {
            body.archive .ast-archive-description {
                text-align: left;
            }
        }

        @media (max-width: 544px) {
            body.archive .ast-archive-description {
                text-align: left;
            }
        }

        .ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo .astra-logo-svg {
            width: 150px;
        }

        .ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo img {
            max-width: 150px;
        }

        @media (max-width: 921px) {
            .ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo .astra-logo-svg {
                width: 120px;
            }

            .ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo img {
                max-width: 120px;
            }
        }

        @media (max-width: 543px) {
            .ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo .astra-logo-svg {
                width: 100px;
            }

            .ast-theme-transparent-header #masthead .site-logo-img .transparent-custom-logo img {
                max-width: 100px;
            }
        }

        @media (min-width: 921px) {
            .ast-theme-transparent-header #masthead {
                position: absolute;
                left: 0;
                right: 0;
            }

            .ast-theme-transparent-header .main-header-bar,
            .ast-theme-transparent-header.ast-header-break-point .main-header-bar {
                background: none;
            }

            body.elementor-editor-active.ast-theme-transparent-header #masthead,
            .fl-builder-edit .ast-theme-transparent-header #masthead,
            body.vc_editor.ast-theme-transparent-header #masthead,
            body.brz-ed.ast-theme-transparent-header #masthead {
                z-index: 0;
            }

            .ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .custom-mobile-logo-link {
                display: none;
            }

            .ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .transparent-custom-logo {
                display: inline-block;
            }

            .ast-theme-transparent-header .ast-above-header,
            .ast-theme-transparent-header .ast-above-header.ast-above-header-bar {
                background-image: none;
                background-color: transparent;
            }

            .ast-theme-transparent-header .ast-below-header {
                background-image: none;
                background-color: transparent;
            }
        }

        @media (max-width: 921px) {
            .ast-theme-transparent-header #masthead {
                position: absolute;
                left: 0;
                right: 0;
            }

            .ast-theme-transparent-header .main-header-bar,
            .ast-theme-transparent-header.ast-header-break-point .main-header-bar {
                background: none;
            }

            body.elementor-editor-active.ast-theme-transparent-header #masthead,
            .fl-builder-edit .ast-theme-transparent-header #masthead,
            body.vc_editor.ast-theme-transparent-header #masthead,
            body.brz-ed.ast-theme-transparent-header #masthead {
                z-index: 0;
            }

            .ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .custom-mobile-logo-link {
                display: none;
            }

            .ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .transparent-custom-logo {
                display: inline-block;
            }

            .ast-theme-transparent-header .ast-above-header,
            .ast-theme-transparent-header .ast-above-header.ast-above-header-bar {
                background-image: none;
                background-color: transparent;
            }

            .ast-theme-transparent-header .ast-below-header {
                background-image: none;
                background-color: transparent;
            }
        }

        .ast-breadcrumbs .trail-browse,
        .ast-breadcrumbs .trail-items,
        .ast-breadcrumbs .trail-items li {
            display: inline-block;
            margin: 0;
            padding: 0;
            border: none;
            background: inherit;
            text-indent: 0;
        }

        .ast-breadcrumbs .trail-browse {
            font-size: inherit;
            font-style: inherit;
            font-weight: inherit;
            color: inherit;
        }

        .ast-breadcrumbs .trail-items {
            list-style: none;
        }

        .trail-items li::after {
            padding: 0 0.3em;
            content: "\00bb";
        }

        .trail-items li:last-of-type::after {
            display: none;
        }

        h1,
        .entry-content h1,
        h2,
        .entry-content h2,
        h3,
        .entry-content h3,
        h4,
        .entry-content h4,
        h5,
        .entry-content h5,
        h6,
        .entry-content h6 {
            color: var(--ast-global-color-2);
        }

        .entry-title a {
            color: var(--ast-global-color-2);
        }

        @media (max-width: 921px) {

            .ast-builder-grid-row-container.ast-builder-grid-row-tablet-3-firstrow .ast-builder-grid-row>* :first-child,
            .ast-builder-grid-row-container.ast-builder-grid-row-tablet-3-lastrow .ast-builder-grid-row>* :last-child {
                grid-column: 1 / -1;
            }
        }

        @media (max-width: 544px) {

            .ast-builder-grid-row-container.ast-builder-grid-row-mobile-3-firstrow .ast-builder-grid-row>* :first-child,
            .ast-builder-grid-row-container.ast-builder-grid-row-mobile-3-lastrow .ast-builder-grid-row>* :last-child {
                grid-column: 1 / -1;
            }
        }

        .ast-builder-layout-element[data-section="title_tagline"] {
            display: flex;
        }

        @media (max-width: 921px) {
            .ast-header-break-point .ast-builder-layout-element[data-section="title_tagline"] {
                display: flex;
            }
        }

        @media (max-width: 544px) {
            .ast-header-break-point .ast-builder-layout-element[data-section="title_tagline"] {
                display: flex;
            }
        }

        .ast-builder-menu-1 {
            font-family: inherit;
            font-weight: inherit;
        }

        .ast-builder-menu-1 .menu-item>.menu-link {
            color: rgba(242, 245, 247, 0.76);
        }

        .ast-builder-menu-1 .menu-item>.ast-menu-toggle {
            color: rgba(242, 245, 247, 0.76);
        }

        .ast-builder-menu-1 .menu-item:hover>.menu-link,
        .ast-builder-menu-1 .inline-on-mobile .menu-item:hover>.ast-menu-toggle {
            color: var(--ast-global-color-5);
        }

        .ast-builder-menu-1 .menu-item:hover>.ast-menu-toggle {
            color: var(--ast-global-color-5);
        }

        .ast-builder-menu-1 .menu-item.current-menu-item>.menu-link,
        .ast-builder-menu-1 .inline-on-mobile .menu-item.current-menu-item>.ast-menu-toggle,
        .ast-builder-menu-1 .current-menu-ancestor>.menu-link {
            color: var(--ast-global-color-5);
        }

        .ast-builder-menu-1 .menu-item.current-menu-item>.ast-menu-toggle {
            color: var(--ast-global-color-5);
        }

        .ast-builder-menu-1 .sub-menu,
        .ast-builder-menu-1 .inline-on-mobile .sub-menu {
            border-top-width: 2px;
            border-bottom-width: 0;
            border-right-width: 0;
            border-left-width: 0;
            border-color: var(--ast-global-color-0);
            border-style: solid;
            border-radius: 0;
        }

        .ast-builder-menu-1 .main-header-menu>.menu-item>.sub-menu,
        .ast-builder-menu-1 .main-header-menu>.menu-item>.astra-full-megamenu-wrapper {
            margin-top: 0;
        }

        .ast-desktop .ast-builder-menu-1 .main-header-menu>.menu-item>.sub-menu:before,
        .ast-desktop .ast-builder-menu-1 .main-header-menu>.menu-item>.astra-full-megamenu-wrapper:before {
            height: calc(0px + 5px);
        }

        .ast-desktop .ast-builder-menu-1 .menu-item .sub-menu .menu-link {
            border-style: none;
        }

        @media (max-width: 921px) {
            .ast-header-break-point .ast-builder-menu-1 .menu-item.menu-item-has-children>.ast-menu-toggle {
                top: 0;
            }

            .ast-builder-menu-1 .menu-item-has-children>.menu-link:after {
                content: unset;
            }

            .ast-builder-menu-1 .main-header-menu>.menu-item>.sub-menu,
            .ast-builder-menu-1 .main-header-menu>.menu-item>.astra-full-megamenu-wrapper {
                margin-top: 0;
            }
        }

        @media (max-width: 544px) {
            .ast-header-break-point .ast-builder-menu-1 .menu-item.menu-item-has-children>.ast-menu-toggle {
                top: 0;
            }

            .ast-builder-menu-1 .main-header-menu>.menu-item>.sub-menu,
            .ast-builder-menu-1 .main-header-menu>.menu-item>.astra-full-megamenu-wrapper {
                margin-top: 0;
            }
        }

        .ast-builder-menu-1 {
            display: flex;
        }

        @media (max-width: 921px) {
            .ast-header-break-point .ast-builder-menu-1 {
                display: flex;
            }
        }

        @media (max-width: 544px) {
            .ast-header-break-point .ast-builder-menu-1 {
                display: flex;
            }
        }

        .ast-builder-social-element:hover {
            color: #0274be;
        }

        .ast-social-stack-desktop .ast-builder-social-element,
        .ast-social-stack-tablet .ast-builder-social-element,
        .ast-social-stack-mobile .ast-builder-social-element {
            margin-top: 6px;
            margin-bottom: 6px;
        }

        .ast-social-color-type-official .ast-builder-social-element,
        .ast-social-color-type-official .social-item-label {
            color: var(--color);
            background-color: var(--background-color);
        }

        .header-social-inner-wrap.ast-social-color-type-official .ast-builder-social-element svg,
        .footer-social-inner-wrap.ast-social-color-type-official .ast-builder-social-element svg {
            fill: currentColor;
        }

        .social-show-label-true .ast-builder-social-element {
            width: auto;
            padding: 0 0.4em;
        }

        [data-section^="section-fb-social-icons-"] .footer-social-inner-wrap {
            text-align: center;
        }

        .ast-footer-social-wrap {
            width: 100%;
        }

        .ast-footer-social-wrap .ast-builder-social-element:first-child {
            margin-left: 0;
        }

        .ast-footer-social-wrap .ast-builder-social-element:last-child {
            margin-right: 0;
        }

        .ast-header-social-wrap .ast-builder-social-element:first-child {
            margin-left: 0;
        }

        .ast-header-social-wrap .ast-builder-social-element:last-child {
            margin-right: 0;
        }

        .ast-builder-social-element {
            line-height: 1;
            color: #3a3a3a;
            background: transparent;
            vertical-align: middle;
            transition: all 0.01s;
            margin-left: 6px;
            margin-right: 6px;
            justify-content: center;
            align-items: center;
        }

        .ast-builder-social-element {
            line-height: 1;
            color: #3a3a3a;
            background: transparent;
            vertical-align: middle;
            transition: all 0.01s;
            margin-left: 6px;
            margin-right: 6px;
            justify-content: center;
            align-items: center;
        }

        .ast-builder-social-element .social-item-label {
            padding-left: 6px;
        }

        .ast-header-social-1-wrap .ast-builder-social-element {
            margin-left: 12.5px;
            margin-right: 12.5px;
        }

        .ast-header-social-1-wrap .ast-builder-social-element svg {
            width: 18px;
            height: 18px;
        }

        .ast-header-social-1-wrap .ast-social-color-type-custom svg {
            fill: var(--ast-global-color-4);
        }

        .ast-header-social-1-wrap .ast-social-color-type-custom .ast-builder-social-element:hover {
            color: var(--ast-global-color-4);
        }

        .ast-header-social-1-wrap .ast-social-color-type-custom .ast-builder-social-element:hover svg {
            fill: var(--ast-global-color-4);
        }

        .ast-header-social-1-wrap .ast-social-color-type-custom .social-item-label {
            color: var(--ast-global-color-4);
        }

        .ast-header-social-1-wrap .ast-builder-social-element:hover .social-item-label {
            color: var(--ast-global-color-4);
        }

        .ast-builder-layout-element[data-section="section-hb-social-icons-1"] {
            display: flex;
        }

        @media (max-width: 921px) {
            .ast-header-break-point .ast-builder-layout-element[data-section="section-hb-social-icons-1"] {
                display: flex;
            }
        }

        @media (max-width: 544px) {
            .ast-header-break-point .ast-builder-layout-element[data-section="section-hb-social-icons-1"] {
                display: flex;
            }
        }

        .site-below-footer-wrap {
            padding-top: 20px;
            padding-bottom: 20px;
        }

        .site-below-footer-wrap[data-section="section-below-footer-builder"] {
            background-color: #eeeeee;
            ;
            min-height: 80px;
        }

        .site-below-footer-wrap[data-section="section-below-footer-builder"] .ast-builder-grid-row {
            max-width: 1200px;
            margin-left: auto;
            margin-right: auto;
        }

        .site-below-footer-wrap[data-section="section-below-footer-builder"] .ast-builder-grid-row,
        .site-below-footer-wrap[data-section="section-below-footer-builder"] .site-footer-section {
            align-items: flex-start;
        }

        .site-below-footer-wrap[data-section="section-below-footer-builder"].ast-footer-row-inline .site-footer-section {
            display: flex;
            margin-bottom: 0;
        }

        .ast-builder-grid-row-full .ast-builder-grid-row {
            grid-template-columns: 1fr;
        }

        @media (max-width: 921px) {
            .site-below-footer-wrap[data-section="section-below-footer-builder"].ast-footer-row-tablet-inline .site-footer-section {
                display: flex;
                margin-bottom: 0;
            }

            .site-below-footer-wrap[data-section="section-below-footer-builder"].ast-footer-row-tablet-stack .site-footer-section {
                display: block;
                margin-bottom: 10px;
            }

            .ast-builder-grid-row-container.ast-builder-grid-row-tablet-full .ast-builder-grid-row {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 544px) {
            .site-below-footer-wrap[data-section="section-below-footer-builder"].ast-footer-row-mobile-inline .site-footer-section {
                display: flex;
                margin-bottom: 0;
            }

            .site-below-footer-wrap[data-section="section-below-footer-builder"].ast-footer-row-mobile-stack .site-footer-section {
                display: block;
                margin-bottom: 10px;
            }

            .ast-builder-grid-row-container.ast-builder-grid-row-mobile-full .ast-builder-grid-row {
                grid-template-columns: 1fr;
            }
        }

        .site-below-footer-wrap[data-section="section-below-footer-builder"] {
            display: grid;
        }

        @media (max-width: 921px) {
            .ast-header-break-point .site-below-footer-wrap[data-section="section-below-footer-builder"] {
                display: grid;
            }
        }

        @media (max-width: 544px) {
            .ast-header-break-point .site-below-footer-wrap[data-section="section-below-footer-builder"] {
                display: grid;
            }
        }

        .ast-footer-copyright {
            text-align: center;
        }

        .ast-footer-copyright {
            color: var(--ast-global-color-3);
        }

        @media (max-width: 921px) {
            .ast-footer-copyright {
                text-align: center;
            }
        }

        @media (max-width: 544px) {
            .ast-footer-copyright {
                text-align: center;
            }
        }

        .ast-footer-copyright.ast-builder-layout-element {
            display: flex;
        }

        @media (max-width: 921px) {
            .ast-header-break-point .ast-footer-copyright.ast-builder-layout-element {
                display: flex;
            }
        }

        @media (max-width: 544px) {
            .ast-header-break-point .ast-footer-copyright.ast-builder-layout-element {
                display: flex;
            }
        }

        .ast-header-break-point .main-header-bar {
            border-bottom-width: 1px;
        }

        @media (min-width: 922px) {
            .main-header-bar {
                border-bottom-width: 1px;
            }
        }

        .main-header-menu .menu-item,
        #astra-footer-menu .menu-item,
        .main-header-bar .ast-masthead-custom-menu-items {
            -js-display: flex;
            display: flex;
            -webkit-box-pack: center;
            -webkit-justify-content: center;
            -moz-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center;
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -webkit-flex-direction: column;
            -moz-box-orient: vertical;
            -moz-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column;
        }

        .main-header-menu>.menu-item>.menu-link,
        #astra-footer-menu>.menu-item>.menu-link {
            height: 100%;
            -webkit-box-align: center;
            -webkit-align-items: center;
            -moz-box-align: center;
            -ms-flex-align: center;
            align-items: center;
            -js-display: flex;
            display: flex;
        }

        .ast-header-break-point .main-navigation ul .menu-item .menu-link .icon-arrow:first-of-type svg {
            top: .2em;
            margin-top: 0px;
            margin-left: 0px;
            width: .65em;
            transform: translate(0, -2px) rotateZ(270deg);
        }

        .ast-mobile-popup-content .ast-submenu-expanded>.ast-menu-toggle {
            transform: rotateX(180deg);
            overflow-y: auto;
        }

        .ast-separate-container .blog-layout-1,
        .ast-separate-container .blog-layout-2,
        .ast-separate-container .blog-layout-3 {
            background-color: transparent;
            background-image: none;
        }

        .ast-separate-container .ast-article-post {
            background-color: var(--ast-global-color-5);
            ;
            background-image: none;
            ;
        }

        @media (max-width: 921px) {
            .ast-separate-container .ast-article-post {
                background-color: var(--ast-global-color-5);
                ;
                background-image: none;
                ;
            }
        }

        @media (max-width: 544px) {
            .ast-separate-container .ast-article-post {
                background-color: var(--ast-global-color-5);
                ;
                background-image: none;
                ;
            }
        }

        .ast-separate-container .ast-article-single:not(.ast-related-post),
        .ast-separate-container .comments-area .comment-respond,
        .ast-separate-container .comments-area .ast-comment-list li,
        .ast-separate-container .ast-woocommerce-container,
        .ast-separate-container .error-404,
        .ast-separate-container .no-results,
        .single.ast-separate-container .site-main .ast-author-meta,
        .ast-separate-container .related-posts-title-wrapper,
        .ast-separate-container.ast-two-container #secondary .widget,
        .ast-separate-container .comments-count-wrapper,
        .ast-box-layout.ast-plain-container .site-content,
        .ast-padded-layout.ast-plain-container .site-content,
        .ast-separate-container .comments-area .comments-title,
        .ast-narrow-container .site-content {
            background-color: var(--ast-global-color-5);
            ;
            background-image: none;
            ;
        }

        @media (max-width: 921px) {

            .ast-separate-container .ast-article-single:not(.ast-related-post),
            .ast-separate-container .comments-area .comment-respond,
            .ast-separate-container .comments-area .ast-comment-list li,
            .ast-separate-container .ast-woocommerce-container,
            .ast-separate-container .error-404,
            .ast-separate-container .no-results,
            .single.ast-separate-container .site-main .ast-author-meta,
            .ast-separate-container .related-posts-title-wrapper,
            .ast-separate-container.ast-two-container #secondary .widget,
            .ast-separate-container .comments-count-wrapper,
            .ast-box-layout.ast-plain-container .site-content,
            .ast-padded-layout.ast-plain-container .site-content,
            .ast-separate-container .comments-area .comments-title,
            .ast-narrow-container .site-content {
                background-color: var(--ast-global-color-5);
                ;
                background-image: none;
                ;
            }
        }

        @media (max-width: 544px) {

            .ast-separate-container .ast-article-single:not(.ast-related-post),
            .ast-separate-container .comments-area .comment-respond,
            .ast-separate-container .comments-area .ast-comment-list li,
            .ast-separate-container .ast-woocommerce-container,
            .ast-separate-container .error-404,
            .ast-separate-container .no-results,
            .single.ast-separate-container .site-main .ast-author-meta,
            .ast-separate-container .related-posts-title-wrapper,
            .ast-separate-container.ast-two-container #secondary .widget,
            .ast-separate-container .comments-count-wrapper,
            .ast-box-layout.ast-plain-container .site-content,
            .ast-padded-layout.ast-plain-container .site-content,
            .ast-separate-container .comments-area .comments-title,
            .ast-narrow-container .site-content {
                background-color: var(--ast-global-color-5);
                ;
                background-image: none;
                ;
            }
        }

        .ast-plain-container,
        .ast-page-builder-template {
            background-color: var(--ast-global-color-5);
            ;
            background-image: none;
            ;
        }

        @media (max-width: 921px) {

            .ast-plain-container,
            .ast-page-builder-template {
                background-color: var(--ast-global-color-5);
                ;
                background-image: none;
                ;
            }
        }

        @media (max-width: 544px) {

            .ast-plain-container,
            .ast-page-builder-template {
                background-color: var(--ast-global-color-5);
                ;
                background-image: none;
                ;
            }
        }


        .ast-mobile-header-content>*,
        .ast-desktop-header-content>* {
            padding: 10px 0;
            height: auto;
        }

        .ast-mobile-header-content>* :first-child,
        .ast-desktop-header-content>* :first-child {
            padding-top: 10px;
        }

        .ast-mobile-header-content>.ast-builder-menu,
        .ast-desktop-header-content>.ast-builder-menu {
            padding-top: 0;
        }

        .ast-mobile-header-content>* :last-child,
        .ast-desktop-header-content>* :last-child {
            padding-bottom: 0;
        }

        .ast-mobile-header-content .ast-search-menu-icon.ast-inline-search label,
        .ast-desktop-header-content .ast-search-menu-icon.ast-inline-search label {
            width: 100%;
        }

        .ast-desktop-header-content .main-header-bar-navigation .ast-submenu-expanded>.ast-menu-toggle::before {
            transform: rotateX(180deg);
        }

        #ast-desktop-header .ast-desktop-header-content,
        .ast-mobile-header-content .ast-search-icon,
        .ast-desktop-header-content .ast-search-icon,
        .ast-mobile-header-wrap .ast-mobile-header-content,
        .ast-main-header-nav-open.ast-popup-nav-open .ast-mobile-header-wrap .ast-mobile-header-content,
        .ast-main-header-nav-open.ast-popup-nav-open .ast-desktop-header-content {
            display: none;
        }

        .ast-main-header-nav-open.ast-header-break-point #ast-desktop-header .ast-desktop-header-content,
        .ast-main-header-nav-open.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content {
            display: block;
        }

        .ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-up>.menu-item>.sub-menu,
        .ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-up>.menu-item .menu-item>.sub-menu,
        .ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-down>.menu-item>.sub-menu,
        .ast-desktop .ast-desktop-header-content .astra-menu-animation-slide-down>.menu-item .menu-item>.sub-menu,
        .ast-desktop .ast-desktop-header-content .astra-menu-animation-fade>.menu-item>.sub-menu,
        .ast-desktop .ast-desktop-header-content .astra-menu-animation-fade>.menu-item .menu-item>.sub-menu {
            opacity: 1;
            visibility: visible;
        }

        .ast-hfb-header.ast-default-menu-enable.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content .main-header-bar-navigation {
            width: unset;
            margin: unset;
        }

        .ast-mobile-header-content.content-align-flex-end .main-header-bar-navigation .menu-item-has-children>.ast-menu-toggle,
        .ast-desktop-header-content.content-align-flex-end .main-header-bar-navigation .menu-item-has-children>.ast-menu-toggle {
            left: calc(20px - 0.907em);
        }

        .ast-mobile-header-content .ast-search-menu-icon,
        .ast-mobile-header-content .ast-search-menu-icon.slide-search,
        .ast-desktop-header-content .ast-search-menu-icon,
        .ast-desktop-header-content .ast-search-menu-icon.slide-search {
            width: 100%;
            position: relative;
            display: block;
            right: auto;
            transform: none;
        }

        .ast-mobile-header-content .ast-search-menu-icon.slide-search .search-form,
        .ast-mobile-header-content .ast-search-menu-icon .search-form,
        .ast-desktop-header-content .ast-search-menu-icon.slide-search .search-form,
        .ast-desktop-header-content .ast-search-menu-icon .search-form {
            right: 0;
            visibility: visible;
            opacity: 1;
            position: relative;
            top: auto;
            transform: none;
            padding: 0;
            display: block;
            overflow: hidden;
        }

        .ast-mobile-header-content .ast-search-menu-icon.ast-inline-search .search-field,
        .ast-mobile-header-content .ast-search-menu-icon .search-field,
        .ast-desktop-header-content .ast-search-menu-icon.ast-inline-search .search-field,
        .ast-desktop-header-content .ast-search-menu-icon .search-field {
            width: 100%;
            padding-right: 5.5em;
        }

        .ast-mobile-header-content .ast-search-menu-icon .search-submit,
        .ast-desktop-header-content .ast-search-menu-icon .search-submit {
            display: block;
            position: absolute;
            height: 100%;
            top: 0;
            right: 0;
            padding: 0 1em;
            border-radius: 0;
        }

        .ast-hfb-header.ast-default-menu-enable.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content .main-header-bar-navigation ul .sub-menu .menu-link {
            padding-left: 30px;
        }

        .ast-hfb-header.ast-default-menu-enable.ast-header-break-point .ast-mobile-header-wrap .ast-mobile-header-content .main-header-bar-navigation .sub-menu .menu-item .menu-item .menu-link {
            padding-left: 40px;
        }

        .ast-mobile-popup-drawer.active .ast-mobile-popup-inner {
            background-color: #ffffff;
            ;
        }

        .ast-mobile-header-wrap .ast-mobile-header-content,
        .ast-desktop-header-content {
            background-color: #ffffff;
            ;
        }

        .ast-mobile-popup-content>*,
        .ast-mobile-header-content>*,
        .ast-desktop-popup-content>*,
        .ast-desktop-header-content>* {
            padding-top: 0;
            padding-bottom: 0;
        }

        .content-align-flex-start .ast-builder-layout-element {
            justify-content: flex-start;
        }

        .content-align-flex-start .main-header-menu {
            text-align: left;
        }

        .ast-mobile-popup-drawer.active .menu-toggle-close {
            color: #3a3a3a;
        }

        .ast-mobile-header-wrap .ast-primary-header-bar,
        .ast-primary-header-bar .site-primary-header-wrap {
            min-height: 110px;
        }

        .ast-desktop .ast-primary-header-bar .main-header-menu>.menu-item {
            line-height: 110px;
        }

        @media (max-width: 921px) {

            #masthead .ast-mobile-header-wrap .ast-primary-header-bar,
            #masthead .ast-mobile-header-wrap .ast-below-header-bar {
                padding-left: 20px;
                padding-right: 20px;
            }
        }

        .ast-header-break-point .ast-primary-header-bar {
            border-bottom-width: 0;
            border-bottom-color: #eaeaea;
            border-bottom-style: solid;
        }

        @media (min-width: 922px) {
            .ast-primary-header-bar {
                border-bottom-width: 0;
                border-bottom-color: #eaeaea;
                border-bottom-style: solid;
            }
        }

        .ast-primary-header-bar {
            background-color: var(--ast-global-color-0);
            ;
            background-image: none;
            ;
        }

        @media (max-width: 921px) {

            .ast-mobile-header-wrap .ast-primary-header-bar,
            .ast-primary-header-bar .site-primary-header-wrap {
                min-height: 100px;
            }
        }

        @media (max-width: 544px) {

            .ast-mobile-header-wrap .ast-primary-header-bar,
            .ast-primary-header-bar .site-primary-header-wrap {
                min-height: 80px;
            }
        }

        .ast-primary-header-bar {
            display: block;
        }

        @media (max-width: 921px) {
            .ast-header-break-point .ast-primary-header-bar {
                display: grid;
            }
        }

        @media (max-width: 544px) {
            .ast-header-break-point .ast-primary-header-bar {
                display: grid;
            }
        }

        [data-section="section-header-mobile-trigger"] .ast-button-wrap .ast-mobile-menu-trigger-minimal {
            color: var(--ast-global-color-5);
            border: none;
            background: transparent;
        }

        [data-section="section-header-mobile-trigger"] .ast-button-wrap .mobile-menu-toggle-icon .ast-mobile-svg {
            width: 20px;
            height: 20px;
            fill: var(--ast-global-color-5);
        }

        [data-section="section-header-mobile-trigger"] .ast-button-wrap .mobile-menu-wrap .mobile-menu {
            color: var(--ast-global-color-5);
        }

        .ast-builder-menu-mobile .main-navigation .menu-item.menu-item-has-children>.ast-menu-toggle {
            top: 0;
        }

        .ast-builder-menu-mobile .main-navigation .menu-item-has-children>.menu-link:after {
            content: unset;
        }

        .ast-hfb-header .ast-builder-menu-mobile .main-navigation .main-header-menu,
        .ast-hfb-header .ast-builder-menu-mobile .main-navigation .main-header-menu,
        .ast-hfb-header .ast-mobile-header-content .ast-builder-menu-mobile .main-navigation .main-header-menu,
        .ast-hfb-header .ast-mobile-popup-content .ast-builder-menu-mobile .main-navigation .main-header-menu {
            border-top-width: 1px;
            border-color: #eaeaea;
        }

        .ast-hfb-header .ast-builder-menu-mobile .main-navigation .menu-item .sub-menu .menu-link,
        .ast-hfb-header .ast-builder-menu-mobile .main-navigation .menu-item .menu-link,
        .ast-hfb-header .ast-builder-menu-mobile .main-navigation .menu-item .sub-menu .menu-link,
        .ast-hfb-header .ast-builder-menu-mobile .main-navigation .menu-item .menu-link,
        .ast-hfb-header .ast-mobile-header-content .ast-builder-menu-mobile .main-navigation .menu-item .sub-menu .menu-link,
        .ast-hfb-header .ast-mobile-header-content .ast-builder-menu-mobile .main-navigation .menu-item .menu-link,
        .ast-hfb-header .ast-mobile-popup-content .ast-builder-menu-mobile .main-navigation .menu-item .sub-menu .menu-link,
        .ast-hfb-header .ast-mobile-popup-content .ast-builder-menu-mobile .main-navigation .menu-item .menu-link {
            border-bottom-width: 1px;
            border-color: #eaeaea;
            border-style: solid;
        }

        .ast-builder-menu-mobile .main-navigation .menu-item.menu-item-has-children>.ast-menu-toggle {
            top: 0;
        }

        @media (max-width: 921px) {
            .ast-builder-menu-mobile .main-navigation .main-header-menu .menu-item>.menu-link {
                color: var(--ast-global-color-2);
                padding-top: 10px;
                padding-bottom: 10px;
                padding-left: 15px;
                padding-right: 15px;
            }

            .ast-builder-menu-mobile .main-navigation .menu-item>.ast-menu-toggle {
                color: var(--ast-global-color-2);
            }

            .ast-builder-menu-mobile .main-navigation .menu-item:hover>.menu-link,
            .ast-builder-menu-mobile .main-navigation .inline-on-mobile .menu-item:hover>.ast-menu-toggle {
                color: var(--ast-global-color-2);
            }

            .ast-builder-menu-mobile .main-navigation .menu-item:hover>.ast-menu-toggle {
                color: var(--ast-global-color-2);
            }

            .ast-builder-menu-mobile .main-navigation .menu-item.current-menu-item>.menu-link,
            .ast-builder-menu-mobile .main-navigation .inline-on-mobile .menu-item.current-menu-item>.ast-menu-toggle,
            .ast-builder-menu-mobile .main-navigation .menu-item.current-menu-ancestor>.menu-link,
            .ast-builder-menu-mobile .main-navigation .menu-item.current-menu-ancestor>.ast-menu-toggle {
                color: var(--ast-global-color-0);
            }

            .ast-builder-menu-mobile .main-navigation .menu-item.current-menu-item>.ast-menu-toggle {
                color: var(--ast-global-color-0);
            }

            .ast-builder-menu-mobile .main-navigation .menu-item.menu-item-has-children>.ast-menu-toggle {
                top: 10px;
                right: calc(15px - 0.907em);
            }

            .ast-builder-menu-mobile .main-navigation .menu-item-has-children>.menu-link:after {
                content: unset;
            }
        }

        @media (max-width: 544px) {
            .ast-builder-menu-mobile .main-navigation .menu-item.menu-item-has-children>.ast-menu-toggle {
                top: 10px;
            }
        }

        .ast-builder-menu-mobile .main-navigation {
            display: block;
        }

        @media (max-width: 921px) {
            .ast-header-break-point .ast-builder-menu-mobile .main-navigation {
                display: block;
            }
        }

        @media (max-width: 544px) {
            .ast-header-break-point .ast-builder-menu-mobile .main-navigation {
                display: block;
            }
        }

        .comment-reply-title {
            font-size: 29px;
            font-size: 1.6111111111111rem;
        }

        .ast-comment-meta {
            line-height: 1.666666667;
            color: var(--ast-global-color-0);
            font-size: 15px;
            font-size: 0.83333333333333rem;
        }

        .ast-comment-list #cancel-comment-reply-link {
            font-size: 18px;
            font-size: 1rem;
        }

        .comments-title {
            padding: 1em 0 0;
        }

        .comments-title {
            font-weight: normal;
            word-wrap: break-word;
        }

        .ast-comment-list {
            margin: 0;
            word-wrap: break-word;
            padding-bottom: 0;
            list-style: none;
        }

        .ast-comment-list li {
            list-style: none;
        }

        .ast-comment-list .ast-comment-edit-reply-wrap {
            -js-display: flex;
            display: flex;
            justify-content: flex-end;
        }

        .ast-comment-list .ast-edit-link {
            flex: 1;
        }

        .ast-comment-list .comment-awaiting-moderation {
            margin-bottom: 0;
        }

        .ast-comment {
            padding: 0;
        }

        .ast-comment-info img {
            border-radius: 50%;
        }

        .ast-comment-cite-wrap cite {
            font-style: normal;
        }

        .comment-reply-title {
            padding-top: 1em;
            font-weight: normal;
            line-height: 1.65;
        }

        .ast-comment-meta {
            margin-bottom: 0.5em;
        }

        .comments-area {
            border-top: 1px solid #eeeeee;
            margin-top: 2em;
        }

        .comments-area .comment-form-comment {
            width: 100%;
            border: none;
            margin: 0;
            padding: 0;
        }

        .comments-area .comment-notes,
        .comments-area .comment-textarea,
        .comments-area .form-allowed-tags {
            margin-bottom: 1.5em;
        }

        .comments-area .form-submit {
            margin-bottom: 0;
        }

        .comments-area textarea#comment,
        .comments-area .ast-comment-formwrap input[type="text"] {
            width: 100%;
            border-radius: 0;
            vertical-align: middle;
            margin-bottom: 10px;
        }

        .comments-area .no-comments {
            margin-top: 0.5em;
            margin-bottom: 0.5em;
        }

        .comments-area p.logged-in-as {
            margin-bottom: 1em;
        }

        .ast-separate-container .comments-area {
            border-top: 0;
        }

        .ast-separate-container .ast-comment-list {
            padding-bottom: 0;
        }

        .ast-separate-container .ast-comment-list li {
            background-color: #fff;
        }

        .ast-separate-container .ast-comment-list li.depth-1 .children li {
            padding-bottom: 0;
            padding-top: 0;
            margin-bottom: 0;
        }

        .ast-separate-container .ast-comment-list li.depth-1 .ast-comment,
        .ast-separate-container .ast-comment-list li.depth-2 .ast-comment {
            border-bottom: 0;
        }

        .ast-separate-container .ast-comment-list .comment-respond {
            padding-top: 0;
            padding-bottom: 1em;
            background-color: transparent;
        }

        .ast-separate-container .ast-comment-list .pingback p {
            margin-bottom: 0;
        }

        .ast-separate-container .ast-comment-list .bypostauthor {
            padding: 2em;
            margin-bottom: 1em;
        }

        .ast-separate-container .ast-comment-list .bypostauthor li {
            background: transparent;
            margin-bottom: 0;
            padding: 0 0 0 2em;
        }

        .ast-separate-container .comment-reply-title {
            padding-top: 0;
        }

        .comment-content a {
            word-wrap: break-word;
        }

        .comment-form-legend {
            margin-bottom: unset;
            padding: 0 0.5em;
        }

        .ast-plain-container .ast-comment,
        .ast-page-builder-template .ast-comment {
            padding: 2em 0;
        }

        .page.ast-page-builder-template .comments-area {
            margin-top: 2em;
        }

        .ast-comment-list li.depth-1 .ast-comment,
        .ast-comment-list li.depth-2 .ast-comment {
            border-bottom: 1px solid #eeeeee;
        }

        .ast-comment-list .children {
            margin-left: 2em;
        }

        @media (max-width: 992px) {
            .ast-comment-list .children {
                margin-left: 1em;
            }
        }

        .ast-comment-list #cancel-comment-reply-link {
            white-space: nowrap;
            font-size: 15px;
            font-size: 1rem;
            margin-left: 1em;
        }

        .ast-comment-info {
            display: flex;
            position: relative;
        }

        .ast-comment-meta {
            justify-content: right;
            padding: 0 3.4em 1.60em;
        }

        .ast-comment-time .timendate {
            margin-right: 0.5em;
        }

        .comments-area #wp-comment-cookies-consent {
            margin-right: 10px;
        }

        .ast-page-builder-template .comments-area {
            padding-left: 20px;
            padding-right: 20px;
            margin-top: 0;
            margin-bottom: 2em;
        }

        .ast-separate-container .ast-comment-list .bypostauthor .bypostauthor {
            background: transparent;
            margin-bottom: 0;
            padding-right: 0;
            padding-bottom: 0;
            padding-top: 0;
        }

        @media (min-width: 922px) {
            .ast-separate-container .ast-comment-list li .comment-respond {
                padding-left: 2.66666em;
                padding-right: 2.66666em;
            }
        }

        @media (max-width: 544px) {
            .ast-separate-container .ast-comment-list li.depth-1 {
                padding: 1.5em 1em;
                margin-bottom: 1.5em;
            }

            .ast-separate-container .ast-comment-list .bypostauthor {
                padding: .5em;
            }

            .ast-separate-container .comment-respond {
                padding: 1.5em 1em;
            }

            .ast-separate-container .ast-comment-list .bypostauthor li {
                padding: 0 0 0 .5em;
            }

            .ast-comment-list .children {
                margin-left: 0.66666em;
            }
        }

        @media (max-width: 921px) {
            .ast-comment-avatar-wrap img {
                max-width: 2.5em;
            }

            .comments-area {
                margin-top: 1.5em;
            }

            .ast-comment-meta {
                padding: 0 1.8888em 1.3333em;
            }

            .ast-separate-container .ast-comment-list li.depth-1 {
                padding: 1.5em 2.14em;
            }

            .ast-separate-container .comment-respond {
                padding: 2em 2.14em;
            }

            .ast-comment-avatar-wrap {
                margin-right: 0.5em;
            }
        }
    </style>
    <link rel='stylesheet' id='astra-google-fonts-css'
        href='https://fonts.googleapis.com/css?family=Inter%3A400%2C600%7CPlus+Jakarta+Sans%3A600&#038;display=fallback&#038;ver=4.0.2'
        media='all' />
    <link rel='stylesheet' id='wp-block-library-css'
        href='https://wp-themes.com/wp-content/plugins/gutenberg/build/block-library/style.css?ver=15.3.1'
        media='all' />
    <style id='global-styles-inline-css'>
        body {
            --wp--preset--color--black: #000000;
            --wp--preset--color--cyan-bluish-gray: #abb8c3;
            --wp--preset--color--white: #ffffff;
            --wp--preset--color--pale-pink: #f78da7;
            --wp--preset--color--vivid-red: #cf2e2e;
            --wp--preset--color--luminous-vivid-orange: #ff6900;
            --wp--preset--color--luminous-vivid-amber: #fcb900;
            --wp--preset--color--light-green-cyan: #7bdcb5;
            --wp--preset--color--vivid-green-cyan: #00d084;
            --wp--preset--color--pale-cyan-blue: #8ed1fc;
            --wp--preset--color--vivid-cyan-blue: #0693e3;
            --wp--preset--color--vivid-purple: #9b51e0;
            --wp--preset--color--ast-global-color-0: var(--ast-global-color-0);
            --wp--preset--color--ast-global-color-1: var(--ast-global-color-1);
            --wp--preset--color--ast-global-color-2: var(--ast-global-color-2);
            --wp--preset--color--ast-global-color-3: var(--ast-global-color-3);
            --wp--preset--color--ast-global-color-4: var(--ast-global-color-4);
            --wp--preset--color--ast-global-color-5: var(--ast-global-color-5);
            --wp--preset--color--ast-global-color-6: var(--ast-global-color-6);
            --wp--preset--color--ast-global-color-7: var(--ast-global-color-7);
            --wp--preset--color--ast-global-color-8: var(--ast-global-color-8);
            --wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg, rgba(6, 147, 227, 1) 0%, rgb(155, 81, 224) 100%);
            --wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg, rgb(122, 220, 180) 0%, rgb(0, 208, 130) 100%);
            --wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg, rgba(252, 185, 0, 1) 0%, rgba(255, 105, 0, 1) 100%);
            --wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg, rgba(255, 105, 0, 1) 0%, rgb(207, 46, 46) 100%);
            --wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg, rgb(238, 238, 238) 0%, rgb(169, 184, 195) 100%);
            --wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg, rgb(74, 234, 220) 0%, rgb(151, 120, 209) 20%, rgb(207, 42, 186) 40%, rgb(238, 44, 130) 60%, rgb(251, 105, 98) 80%, rgb(254, 248, 76) 100%);
            --wp--preset--gradient--blush-light-purple: linear-gradient(135deg, rgb(255, 206, 236) 0%, rgb(152, 150, 240) 100%);
            --wp--preset--gradient--blush-bordeaux: linear-gradient(135deg, rgb(254, 205, 165) 0%, rgb(254, 45, 45) 50%, rgb(107, 0, 62) 100%);
            --wp--preset--gradient--luminous-dusk: linear-gradient(135deg, rgb(255, 203, 112) 0%, rgb(199, 81, 192) 50%, rgb(65, 88, 208) 100%);
            --wp--preset--gradient--pale-ocean: linear-gradient(135deg, rgb(255, 245, 203) 0%, rgb(182, 227, 212) 50%, rgb(51, 167, 181) 100%);
            --wp--preset--gradient--electric-grass: linear-gradient(135deg, rgb(202, 248, 128) 0%, rgb(113, 206, 126) 100%);
            --wp--preset--gradient--midnight: linear-gradient(135deg, rgb(2, 3, 129) 0%, rgb(40, 116, 252) 100%);
            --wp--preset--duotone--dark-grayscale: url('#wp-duotone-dark-grayscale');
            --wp--preset--duotone--grayscale: url('#wp-duotone-grayscale');
            --wp--preset--duotone--purple-yellow: url('#wp-duotone-purple-yellow');
            --wp--preset--duotone--blue-red: url('#wp-duotone-blue-red');
            --wp--preset--duotone--midnight: url('#wp-duotone-midnight');
            --wp--preset--duotone--magenta-yellow: url('#wp-duotone-magenta-yellow');
            --wp--preset--duotone--purple-green: url('#wp-duotone-purple-green');
            --wp--preset--duotone--blue-orange: url('#wp-duotone-blue-orange');
            --wp--preset--font-size--small: 13px;
            --wp--preset--font-size--medium: 20px;
            --wp--preset--font-size--large: 36px;
            --wp--preset--font-size--x-large: 42px;
            --wp--preset--spacing--20: 0.44rem;
            --wp--preset--spacing--30: 0.67rem;
            --wp--preset--spacing--40: 1rem;
            --wp--preset--spacing--50: 1.5rem;
            --wp--preset--spacing--60: 2.25rem;
            --wp--preset--spacing--70: 3.38rem;
            --wp--preset--spacing--80: 5.06rem;
            --wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);
            --wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);
            --wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);
            --wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);
            --wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);
        }

        body {
            margin: 0;
            --wp--style--global--content-size: var(--wp--custom--ast-content-width-size);
            --wp--style--global--wide-size: var(--wp--custom--ast-wide-width-size);
        }

        .wp-site-blocks>.alignleft {
            float: left;
            margin-right: 2em;
        }

        .wp-site-blocks>.alignright {
            float: right;
            margin-left: 2em;
        }

        .wp-site-blocks>.aligncenter {
            justify-content: center;
            margin-left: auto;
            margin-right: auto;
        }

        .wp-site-blocks>* {
            margin-block-start: 0;
            margin-block-end: 0;
        }

        .wp-site-blocks>*+* {
            margin-block-start: 24px;
        }

        body {
            --wp--style--block-gap: 24px;
        }

        body .is-layout-flow>* {
            margin-block-start: 0;
            margin-block-end: 0;
        }

        body .is-layout-flow>*+* {
            margin-block-start: 24px;
            margin-block-end: 0;
        }

        body .is-layout-constrained>* {
            margin-block-start: 0;
            margin-block-end: 0;
        }

        body .is-layout-constrained>*+* {
            margin-block-start: 24px;
            margin-block-end: 0;
        }

        body .is-layout-flex {
            gap: 24px;
        }

        body .is-layout-flow>.alignleft {
            float: left;
            margin-inline-start: 0;
            margin-inline-end: 2em;
        }

        body .is-layout-flow>.alignright {
            float: right;
            margin-inline-start: 2em;
            margin-inline-end: 0;
        }

        body .is-layout-flow>.aligncenter {
            margin-left: auto !important;
            margin-right: auto !important;
        }

        body .is-layout-constrained>.alignleft {
            float: left;
            margin-inline-start: 0;
            margin-inline-end: 2em;
        }

        body .is-layout-constrained>.alignright {
            float: right;
            margin-inline-start: 2em;
            margin-inline-end: 0;
        }

        body .is-layout-constrained>.aligncenter {
            margin-left: auto !important;
            margin-right: auto !important;
        }

        body .is-layout-constrained> :where(:not(.alignleft):not(.alignright):not(.alignfull)) {
            max-width: var(--wp--style--global--content-size);
            margin-left: auto !important;
            margin-right: auto !important;
        }

        body .is-layout-constrained>.alignwide {
            max-width: var(--wp--style--global--wide-size);
        }

        body .is-layout-flex {
            display: flex;
        }

        body .is-layout-flex {
            flex-wrap: wrap;
            align-items: center;
        }

        body .is-layout-flex>* {
            margin: 0;
        }

        body {
            padding-top: 0px;
            padding-right: 0px;
            padding-bottom: 0px;
            padding-left: 0px;
        }

        a:where(:not(.wp-element-button)) {
            text-decoration: none;
        }

        .wp-element-button,
        .wp-block-button__link {
            background-color: #32373c;
            border-width: 0;
            color: #fff;
            font-family: inherit;
            font-size: inherit;
            line-height: inherit;
            padding: calc(0.667em + 2px) calc(1.333em + 2px);
            text-decoration: none;
        }

        .has-black-color {
            color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-color {
            color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-color {
            color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-color {
            color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-color {
            color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-color {
            color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-color {
            color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-color {
            color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-color {
            color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-color {
            color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-color {
            color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-color {
            color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-ast-global-color-0-color {
            color: var(--wp--preset--color--ast-global-color-0) !important;
        }

        .has-ast-global-color-1-color {
            color: var(--wp--preset--color--ast-global-color-1) !important;
        }

        .has-ast-global-color-2-color {
            color: var(--wp--preset--color--ast-global-color-2) !important;
        }

        .has-ast-global-color-3-color {
            color: var(--wp--preset--color--ast-global-color-3) !important;
        }

        .has-ast-global-color-4-color {
            color: var(--wp--preset--color--ast-global-color-4) !important;
        }

        .has-ast-global-color-5-color {
            color: var(--wp--preset--color--ast-global-color-5) !important;
        }

        .has-ast-global-color-6-color {
            color: var(--wp--preset--color--ast-global-color-6) !important;
        }

        .has-ast-global-color-7-color {
            color: var(--wp--preset--color--ast-global-color-7) !important;
        }

        .has-ast-global-color-8-color {
            color: var(--wp--preset--color--ast-global-color-8) !important;
        }

        .has-black-background-color {
            background-color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-background-color {
            background-color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-background-color {
            background-color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-background-color {
            background-color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-background-color {
            background-color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-background-color {
            background-color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-background-color {
            background-color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-background-color {
            background-color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-background-color {
            background-color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-background-color {
            background-color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-background-color {
            background-color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-background-color {
            background-color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-ast-global-color-0-background-color {
            background-color: var(--wp--preset--color--ast-global-color-0) !important;
        }

        .has-ast-global-color-1-background-color {
            background-color: var(--wp--preset--color--ast-global-color-1) !important;
        }

        .has-ast-global-color-2-background-color {
            background-color: var(--wp--preset--color--ast-global-color-2) !important;
        }

        .has-ast-global-color-3-background-color {
            background-color: var(--wp--preset--color--ast-global-color-3) !important;
        }

        .has-ast-global-color-4-background-color {
            background-color: var(--wp--preset--color--ast-global-color-4) !important;
        }

        .has-ast-global-color-5-background-color {
            background-color: var(--wp--preset--color--ast-global-color-5) !important;
        }

        .has-ast-global-color-6-background-color {
            background-color: var(--wp--preset--color--ast-global-color-6) !important;
        }

        .has-ast-global-color-7-background-color {
            background-color: var(--wp--preset--color--ast-global-color-7) !important;
        }

        .has-ast-global-color-8-background-color {
            background-color: var(--wp--preset--color--ast-global-color-8) !important;
        }

        .has-black-border-color {
            border-color: var(--wp--preset--color--black) !important;
        }

        .has-cyan-bluish-gray-border-color {
            border-color: var(--wp--preset--color--cyan-bluish-gray) !important;
        }

        .has-white-border-color {
            border-color: var(--wp--preset--color--white) !important;
        }

        .has-pale-pink-border-color {
            border-color: var(--wp--preset--color--pale-pink) !important;
        }

        .has-vivid-red-border-color {
            border-color: var(--wp--preset--color--vivid-red) !important;
        }

        .has-luminous-vivid-orange-border-color {
            border-color: var(--wp--preset--color--luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-amber-border-color {
            border-color: var(--wp--preset--color--luminous-vivid-amber) !important;
        }

        .has-light-green-cyan-border-color {
            border-color: var(--wp--preset--color--light-green-cyan) !important;
        }

        .has-vivid-green-cyan-border-color {
            border-color: var(--wp--preset--color--vivid-green-cyan) !important;
        }

        .has-pale-cyan-blue-border-color {
            border-color: var(--wp--preset--color--pale-cyan-blue) !important;
        }

        .has-vivid-cyan-blue-border-color {
            border-color: var(--wp--preset--color--vivid-cyan-blue) !important;
        }

        .has-vivid-purple-border-color {
            border-color: var(--wp--preset--color--vivid-purple) !important;
        }

        .has-ast-global-color-0-border-color {
            border-color: var(--wp--preset--color--ast-global-color-0) !important;
        }

        .has-ast-global-color-1-border-color {
            border-color: var(--wp--preset--color--ast-global-color-1) !important;
        }

        .has-ast-global-color-2-border-color {
            border-color: var(--wp--preset--color--ast-global-color-2) !important;
        }

        .has-ast-global-color-3-border-color {
            border-color: var(--wp--preset--color--ast-global-color-3) !important;
        }

        .has-ast-global-color-4-border-color {
            border-color: var(--wp--preset--color--ast-global-color-4) !important;
        }

        .has-ast-global-color-5-border-color {
            border-color: var(--wp--preset--color--ast-global-color-5) !important;
        }

        .has-ast-global-color-6-border-color {
            border-color: var(--wp--preset--color--ast-global-color-6) !important;
        }

        .has-ast-global-color-7-border-color {
            border-color: var(--wp--preset--color--ast-global-color-7) !important;
        }

        .has-ast-global-color-8-border-color {
            border-color: var(--wp--preset--color--ast-global-color-8) !important;
        }

        .has-vivid-cyan-blue-to-vivid-purple-gradient-background {
            background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;
        }

        .has-light-green-cyan-to-vivid-green-cyan-gradient-background {
            background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;
        }

        .has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background {
            background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;
        }

        .has-luminous-vivid-orange-to-vivid-red-gradient-background {
            background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;
        }

        .has-very-light-gray-to-cyan-bluish-gray-gradient-background {
            background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;
        }

        .has-cool-to-warm-spectrum-gradient-background {
            background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;
        }

        .has-blush-light-purple-gradient-background {
            background: var(--wp--preset--gradient--blush-light-purple) !important;
        }

        .has-blush-bordeaux-gradient-background {
            background: var(--wp--preset--gradient--blush-bordeaux) !important;
        }

        .has-luminous-dusk-gradient-background {
            background: var(--wp--preset--gradient--luminous-dusk) !important;
        }

        .has-pale-ocean-gradient-background {
            background: var(--wp--preset--gradient--pale-ocean) !important;
        }

        .has-electric-grass-gradient-background {
            background: var(--wp--preset--gradient--electric-grass) !important;
        }

        .has-midnight-gradient-background {
            background: var(--wp--preset--gradient--midnight) !important;
        }

        .has-small-font-size {
            font-size: var(--wp--preset--font-size--small) !important;
        }

        .has-medium-font-size {
            font-size: var(--wp--preset--font-size--medium) !important;
        }

        .has-large-font-size {
            font-size: var(--wp--preset--font-size--large) !important;
        }

        .has-x-large-font-size {
            font-size: var(--wp--preset--font-size--x-large) !important;
        }

        .wp-block-pullquote {
            font-size: 1.5em;
            line-height: 1.6;
        }

        .wp-block-navigation a:where(:not(.wp-element-button)) {
            color: inherit;
        }

        .login-btn .btn-custom {
            border-radius: 50px;
            background-color: #C7A4FF;
            color: #FFFFFF;
        }

        .login-btn .btn-custom:hover {
            border-radius: 50px;
            background-color: #008F7A;
            color: #FFFFFF;
        }

        .logo-text {
            background-color: transparent;
            color: #fff;
            font-family: Arial, sans-serif;
            font-size: 20px;
            text-align: center;
            padding: 20px;
        }

        .logo-text p {
            margin: 0;
            padding: 0;            font-family: 'Prompt', sans-serif;
            background-image: linear-gradient(to right top, #d16ba5, #c777b9, #ba83ca, #aa8fd8, #9a9ae1, #8aa7ec, #79b3f4, #69bff8, #52cffe, #41dfff, #46eefa, #5ffbf1);
			-webkit-background-clip: text;
			-moz-background-clip: text;
			background-clip: text;
			color: transparent;
			text-fill-color: transparent;
			background-size: auto 100%;
			display: inline-block;
        }
    </style>
    <link rel='stylesheet' id='classic-theme-styles-css' <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">



</head>

<body itemtype='https://schema.org/WebPage' itemscope='itemscope'
    class="home page-template-default page page-id-10000 wp-custom-logo ast-desktop ast-plain-container ast-no-sidebar astra-4.0.2 ast-single-post ast-inherit-site-logo-transparent ast-theme-transparent-header ast-hfb-header">


    <div class="hfeed site" id="page">
        <header
            class="site-header header-main-layout-1 ast-primary-menu-enabled ast-hide-custom-menu-mobile ast-builder-menu-toggle-icon ast-mobile-header-inline"
            id="masthead" itemtype="https://schema.org/WPHeader" itemscope="itemscope" itemid="#masthead">
            <div id="ast-desktop-header" data-toggle-type="dropdown">
                <div class="ast-main-header-wrap main-header-bar-wrap ">
                    <div class="ast-primary-header-bar ast-primary-header main-header-bar site-header-focus-item"
                        data-section="section-primary-header-builder">
                        <div class="site-primary-header-wrap ast-builder-grid-row-container site-header-focus-item ast-container"
                            data-section="section-primary-header-builder">
                            <div
                                class="ast-builder-grid-row ast-builder-grid-row-has-sides ast-builder-grid-row-no-center">
                                <div
                                    class="site-header-primary-section-left site-header-section ast-flex site-header-section-left">
                                    <div class="ast-builder-layout-element ast-flex site-header-focus-item"
                                        data-section="title_tagline">
                                        <div class="site-branding ast-site-identity"
                                            itemtype="https://schema.org/Organization" itemscope="itemscope">
                                            <span class="site-logo-img">
                                                <a href="#" class="custom-logo-link" rel="home" aria-current="page">
                                                    <div class="logo-text">
                                                        <p>ชื่อไรดีนึกไม่ออก</p>
                                                    </div>
                                                    <!--   <img style="border-radius: 50px;" width="150em" src="./img/logo.png" class="custom-logo" alt="Astra" decoding="async" /> -->
                                                </a>
                                            </span>
                                        </div>
                                        <!-- .site-branding -->
                                    </div>
                                </div>
                                <div
                                    class="site-header-primary-section-right site-header-section ast-flex ast-grid-right-section">
                                    <div class="ast-builder-menu-1 ast-builder-menu ast-flex ast-builder-menu-1-focus-item ast-builder-layout-element site-header-focus-item"
                                        data-section="section-hb-menu-1">
                                        <div class="ast-main-header-bar-alignment">
                                            <div class="main-header-bar-navigation">
                                                <nav class="site-navigation ast-flex-grow-1 navigation-accessibility site-header-focus-item"
                                                    id="primary-site-navigation" aria-label="Site Navigation"
                                                    itemtype="https://schema.org/SiteNavigationElement"
                                                    itemscope="itemscope">
                                                    <div class="main-navigation ast-inline-flex">
                                                        <ul id="ast-hf-menu-1"
                                                            class="main-header-menu ast-menu-shadow ast-nav-menu ast-flex  submenu-with-border stack-on-mobile">
                                                            <li id="menu-item-10004"
                                                                class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-10000 current_page_item menu-item-10004">
                                                                <a href="#" aria-current="page"
                                                                    class="menu-link">Home</a>
                                                            </li>
                                                            <li id="menu-item-10005"
                                                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10005">
                                                                <a href="#services" class="menu-link">Services</a>
                                                            </li>
                                                            <li id="menu-item-10006"
                                                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10006">
                                                                <a href="#about" class="menu-link">About</a>
                                                            </li>
                                                            <li id="menu-item-10007"
                                                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10007">
                                                                <a href="#reviews" class="menu-link">Reviews</a>
                                                            </li>
                                                            <li id="menu-item-10008"
                                                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10008">
                                                                <a href="#whyus" class="menu-link">Why Us</a>
                                                            </li>
                                                            <li id="menu-item-10009"
                                                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10009">
                                                                <a href="#contact" class="menu-link">Contact</a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </nav>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="ast-builder-layout-element ast-flex site-header-focus-item"
                                        data-section="section-hb-social-icons-1">
                                        <div class="ast-header-social-1-wrap ast-header-social-wrap">
                                            <div
                                                class="header-social-inner-wrap element-social-inner-wrap social-show-label-false ast-social-color-type-custom ast-social-stack-none ast-social-element-style-filled">
                                                <a href="https://www.facebook.com/profile.php?id=100090775727245"
                                                    aria-label=Facebook target="_blank" rel="noopener noreferrer"
                                                    style="--color: #557dbc; --background-color: transparent;"
                                                    class="ast-builder-social-element ast-inline-flex ast-facebook header-social-item">
                                                    <span class="ahfb-svg-iconset ast-inline-flex svg-baseline">
                                                        <svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 512 512'>
                                                            <path
                                                                d='M504 256C504 119 393 8 256 8S8 119 8 256c0 123.78 90.69 226.38 209.25 245V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.28c-30.8 0-40.41 19.12-40.41 38.73V256h68.78l-11 71.69h-57.78V501C413.31 482.38 504 379.78 504 256z'>
                                                            </path>
                                                        </svg>
                                                    </span>
                                                </a>
                                                <a href="https://lin.ee/LkR860f" target="_blank"><img
                                                        style="border: 0; border-radius:50px;"
                                                        src="https://scdn.line-apps.com/n/line_add_friends/btn/th.png"
                                                        alt="เพิ่มเพื่อน" width="80rem">
                                                </a>
                                                </a>
                                            </div>
                                        </div>
                                        <div class="login-btn" style="margin-left: 2rem;">
                                            <a href="./Login/index.php"> <button class="btn btn-custom"
                                                    type="button">Login</button></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="ast-desktop-header-content content-align-flex-start "></div>
            </div>
            <!-- Main Header Bar Wrap -->
            <div id="ast-mobile-header" class="ast-mobile-header-wrap " data-type="dropdown">
                <div class="ast-main-header-wrap main-header-bar-wrap">
                    <div class="ast-primary-header-bar ast-primary-header main-header-bar site-primary-header-wrap site-header-focus-item ast-builder-grid-row-layout-default ast-builder-grid-row-tablet-layout-default ast-builder-grid-row-mobile-layout-default"
                        data-section="section-primary-header-builder">
                        <div class="ast-builder-grid-row ast-builder-grid-row-has-sides ast-builder-grid-row-no-center">
                            <div
                                class="site-header-primary-section-left site-header-section ast-flex site-header-section-left">
                                <div class="ast-builder-layout-element ast-flex site-header-focus-item"
                                    data-section="title_tagline">
                                    <div class="site-branding ast-site-identity"
                                        itemtype="https://schema.org/Organization" itemscope="itemscope">
                                        <span class="site-logo-img">
                                            <a href="#" class="custom-logo-link" rel="home" aria-current="page">
                                                <img src="https://wp-themes.com/wp-content/themes/astra/inc/assets/images/starter-content/logo.png"
                                                    class="custom-logo" alt="Astra" decoding="async" />
                                            </a>
                                        </span>
                                    </div>
                                    <!-- .site-branding -->
                                </div>
                            </div>
                            <div
                                class="site-header-primary-section-right site-header-section ast-flex ast-grid-right-section">
                                <div class="ast-builder-layout-element ast-flex site-header-focus-item"
                                    data-section="section-header-mobile-trigger">
                                    <div class="ast-button-wrap">
                                        <button type="button"
                                            class="menu-toggle main-header-menu-toggle ast-mobile-menu-trigger-minimal"
                                            aria-expanded="false">
                                            <span class="screen-reader-text">Main Menu</span>
                                            <span class="mobile-menu-toggle-icon">
                                                <span class="ahfb-svg-iconset ast-inline-flex svg-baseline">
                                                    <svg class='ast-mobile-svg ast-menu-svg' fill='currentColor'
                                                        version='1.1' xmlns='http://www.w3.org/2000/svg' width='24'
                                                        height='24' viewBox='0 0 24 24'>
                                                        <path
                                                            d='M3 13h18c0.552 0 1-0.448 1-1s-0.448-1-1-1h-18c-0.552 0-1 0.448-1 1s0.448 1 1 1zM3 7h18c0.552 0 1-0.448 1-1s-0.448-1-1-1h-18c-0.552 0-1 0.448-1 1s0.448 1 1 1zM3 19h18c0.552 0 1-0.448 1-1s-0.448-1-1-1h-18c-0.552 0-1 0.448-1 1s0.448 1 1 1z'>
                                                        </path>
                                                    </svg>
                                                </span>
                                                <span class="ahfb-svg-iconset ast-inline-flex svg-baseline">
                                                    <svg class='ast-mobile-svg ast-close-svg' fill='currentColor'
                                                        version='1.1' xmlns='http://www.w3.org/2000/svg' width='24'
                                                        height='24' viewBox='0 0 24 24'>
                                                        <path
                                                            d='M5.293 6.707l5.293 5.293-5.293 5.293c-0.391 0.391-0.391 1.024 0 1.414s1.024 0.391 1.414 0l5.293-5.293 5.293 5.293c0.391 0.391 1.024 0.391 1.414 0s0.391-1.024 0-1.414l-5.293-5.293 5.293-5.293c0.391-0.391 0.391-1.024 0-1.414s-1.024-0.391-1.414 0l-5.293 5.293-5.293-5.293c-0.391-0.391-1.024-0.391-1.414 0s-0.391 1.024 0 1.414z'>
                                                        </path>
                                                    </svg>
                                                </span>
                                            </span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="ast-mobile-header-content content-align-flex-start ">
                    <div class="ast-builder-menu-mobile ast-builder-menu ast-builder-menu-mobile-focus-item ast-builder-layout-element site-header-focus-item"
                        data-section="section-header-mobile-menu">
                        <div class="ast-main-header-bar-alignment">
                            <div class="main-header-bar-navigation">
                                <nav class="site-navigation ast-flex-grow-1 navigation-accessibility site-header-focus-item"
                                    id="ast-mobile-site-navigation" aria-label="Site Navigation"
                                    itemtype="https://schema.org/SiteNavigationElement" itemscope="itemscope">
                                    <div class="main-navigation">
                                        <ul id="ast-hf-mobile-menu"
                                            class="main-header-menu ast-nav-menu ast-flex  submenu-with-border astra-menu-animation-fade  stack-on-mobile">
                                            <li id="menu-item-10010"
                                                class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-10000 current_page_item menu-item-10010">
                                                <a href="#" aria-current="page" class="menu-link">Home</a>
                                            </li>
                                            <li id="menu-item-10011"
                                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10011">
                                                <a href="#services" class="menu-link">Services</a>
                                            </li>
                                            <li id="menu-item-10012"
                                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10012">
                                                <a href="#about" class="menu-link">About</a>
                                            </li>
                                            <li id="menu-item-10013"
                                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10013">
                                                <a href="#reviews" class="menu-link">Reviews</a>
                                            </li>
                                            <li id="menu-item-10014"
                                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10014">
                                                <a href="#whyus" class="menu-link">Why Us</a>
                                            </li>
                                            <li id="menu-item-10015"
                                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10015">
                                                <a href="#contact" class="menu-link">Contact</a>
                                            </li>
                                            <li id="menu-item-10016"
                                                class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10016">
                                                <a href="./Login/" class="menu-link">Login</a>
                                            </li>
                                        </ul>
                                    </div>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- #masthead -->
        <div id="content" class="site-content">
            <div class="ast-container">

                <div id="primary" class="content-area primary">

                    <main id="main" class="site-main">
                        <article class="post-10000 page type-page status-publish ast-article-single" id="post-10000"
                            itemtype="https://schema.org/CreativeWork" itemscope="itemscope">

                            <header class="entry-header ast-no-thumbnail ast-no-title ast-header-without-markup">
                            </header>
                            <!-- .entry-header -->

                            <div class="entry-content clear" ast-blocks-layout="true" itemprop="text">

                                <div class="wp-block-cover alignfull is-light" style="min-height:720px">
                                    <span aria-hidden="true"
                                        class="wp-block-cover__background has-background-dim-100 has-background-dim has-background-gradient"
                                        style="background:linear-gradient(35deg,rgb(6,150,0) 0%,rgb(130,45,255) 73%,rgb(255,15,255) 100%)"></span>
                                    <div class="wp-block-cover__inner-container">
                                        <div
                                            class="inherit-container-width wp-block-group alignwide is-layout-constrained">
                                            <div class="wp-block-media-text alignwide has-media-on-the-right is-stacked-on-mobile is-vertically-aligned-center"
                                                style="grid-template-columns:auto 43%;">
                                                <div class="wp-block-media-text__content">
                                                    <h1 
                                                        class="has-text-align-left has-white-color has-text-color wp-block-heading">
                                                        Increase visibility for your business!</h1>

                                                    <p style="color: #ffff">
                                                        Start promoting a new business.
                                                        <br>
                                                        by setting up a virtual storefront.
                                                    </p>

                                                    <div class="wp-block-buttons alignwide is-layout-flex">
                                                        <div class="wp-block-button">
                                                            <a class="wp-block-button__link wp-element-button text-white"
                                                                href="#">Rent a virtual storefront</a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <figure class="wp-block-media-text__media">
                                                    <img decoding="async"
                                                        src="./img/wp-block-media-text__media/hero-img.svg" alt=""
                                                        class="wp-image-118 size-full" />
                                                </figure>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="wp-block-group alignfull has-ast-global-color-5-background-color has-background is-layout-constrained wp-container-8"
                                    style="padding-bottom:0px">
                                    <div
                                        class="wp-block-columns are-vertically-aligned-top is-layout-flex wp-container-7">
                                        <div
                                            class="wp-block-column is-vertically-aligned-top is-layout-flow wp-container-3">
                                            <figure class="wp-block-image size-large">
                                                <img decoding="async" src="./img/wp-block-image size-large/building.svg"
                                                    alt="" class="wp-image-134" />
                                            </figure>

                                            <h3 class="has-text-align-left wp-block-heading" style="margin-top:16px">
                                                Local Business</h3>

                                            <p class="has-text-align-left">Lorem ipsum dolor consectetur adipiscing elit
                                                eiusmod.</p>
                                        </div>

                                        <div
                                            class="wp-block-column is-vertically-aligned-top is-layout-flow wp-container-4">
                                            <figure class="wp-block-image size-large">
                                                <img decoding="async"
                                                    src="./img/wp-block-image size-large/shopping-bag.svg" alt=""
                                                    class="wp-image-135" />
                                            </figure>

                                            <h3 class="has-text-align-left wp-block-heading" style="margin-top:16px">
                                                Online Store</h3>

                                            <p class="has-text-align-left">Lorem ipsum dolor consectetur adipiscing elit
                                                eiusmod.</p>
                                        </div>

                                        <div
                                            class="wp-block-column is-vertically-aligned-top is-layout-flow wp-container-5">
                                            <figure class="wp-block-image size-large">
                                                <img decoding="async" src="./img/wp-block-image size-large/blog.svg"
                                                    alt="" class="wp-image-136" />
                                            </figure>

                                            <h3 class="has-text-align-left wp-block-heading" style="margin-top:16px">
                                                Blogging</h3>

                                            <p class="has-text-align-left">Lorem ipsum dolor consectetur adipiscing elit
                                                eiusmod.</p>
                                        </div>

                                        <div
                                            class="wp-block-column is-vertically-aligned-top is-layout-flow wp-container-6">
                                            <figure class="wp-block-image size-large">
                                                <img decoding="async"
                                                    src="./img/wp-block-image size-large/portfolio.svg" alt=""
                                                    class="wp-image-137" />
                                            </figure>

                                            <h3 class="has-text-align-left wp-block-heading" style="margin-top:16px">
                                                Portfolio</h3>

                                            <p class="has-text-align-left">Lorem ipsum dolor consectetur adipiscing elit
                                                eiusmod.</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="wp-block-group alignfull is-layout-constrained wp-container-13"
                                    id="services" style="padding-top:144px;padding-bottom:0px">
                                    <h2 class="wp-block-heading">Our Services</h2>

                                    <div class="wp-block-columns is-layout-flex wp-container-12"
                                        style="margin-top:50px">
                                        <div class="wp-block-column is-layout-flow wp-container-9">
                                            <figure class="wp-block-image size-full">
                                                <img decoding="async"
                                                    src="https://wp-themes.com/wp-content/themes/astra/inc/assets/images/starter-content/branding.jpg"
                                                    alt="" class="wp-image-230" />
                                            </figure>

                                            <h3 class="wp-block-heading" style="margin-top:16px">Branding Design</h3>

                                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae adipisci
                                                laborum inventore iure! Eveniet, ut?</p>
                                        </div>

                                        <div class="wp-block-column is-layout-flow wp-container-10">
                                            <figure class="wp-block-image size-full">
                                                <img decoding="async"
                                                    src="https://wp-themes.com/wp-content/themes/astra/inc/assets/images/starter-content/graphic.jpg"
                                                    alt="" class="wp-image-232" />
                                            </figure>

                                            <h3 class="wp-block-heading" style="margin-top:16px">Graphic Design</h3>

                                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae adipisci
                                                laborum inventore iure! Eveniet, ut?</p>
                                        </div>

                                        <div class="wp-block-column is-layout-flow wp-container-11">
                                            <figure class="wp-block-image size-full">
                                                <img decoding="async"
                                                    src="https://wp-themes.com/wp-content/themes/astra/inc/assets/images/starter-content/web.jpg"
                                                    alt="" class="wp-image-231" />
                                            </figure>

                                            <h3 class="wp-block-heading" style="margin-top:16px">Web Development</h3>

                                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Vitae adipisci
                                                laborum inventore iure! Eveniet, ut?</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="wp-block-group alignfull has-ast-global-color-5-background-color has-background is-layout-constrained wp-container-15"
                                    id="about" style="padding-top:143px;padding-bottom:144px">
                                    <div
                                        class="wp-block-media-text has-media-on-the-right is-stacked-on-mobile is-vertically-aligned-center">
                                        <div class="wp-block-media-text__content">
                                            <div class="inherit-container-width wp-block-group is-layout-constrained"
                                                style="padding-right:80px">
                                                <h2 class="wp-block-heading" style="padding-right:40px">We help teams
                                                    build the business of their dreams</h2>

                                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt
                                                    quam expedita porro provident?</p>

                                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem
                                                    soluta nobis eius eligendi. Cumque pariatur, eligendi a id eaque
                                                    praesentium aspernatur porro harum consectetur perspiciatis dicta?
                                                    Quia iusto laudantium nihil.</p>
                                            </div>
                                        </div>
                                        <figure class="wp-block-media-text__media">
                                            <img decoding="async" src="./img/wp-block-media-text--media/about-us.jpg"
                                                alt="" class="wp-image-237 size-full" />
                                        </figure>
                                    </div>
                                </div>



                                <div class="wp-block-group alignfull is-layout-constrained wp-container-21" id="whyus"
                                    style="padding-top:144px;padding-bottom:144px">
                                    <h2 class="wp-block-heading">Why Choose Us</h2>

                                    <div class="wp-block-columns is-layout-flex wp-container-20"
                                        style="margin-top:60px">
                                        <div class="wp-block-column is-layout-flow wp-container-17">
                                            <figure class="wp-block-image size-large">
                                                <img decoding="async"
                                                    src="https://wp-themes.com/wp-content/themes/astra/inc/assets/images/starter-content/passionate.svg"
                                                    alt="" class="wp-image-162" />
                                            </figure>

                                            <h3 class="wp-block-heading" style="margin-top:16px">Passionate</h3>

                                            <p>Tempor ullamcorper urna, est, lectus amet sit tempor pretium mi sed morbi
                                                cras posuere sit ultrices bibendum augue sit ornare.</p>
                                        </div>

                                        <div class="wp-block-column is-layout-flow wp-container-18">
                                            <figure class="wp-block-image size-large">
                                                <img decoding="async"
                                                    src="https://wp-themes.com/wp-content/themes/astra/inc/assets/images/starter-content/professional.svg"
                                                    alt="" class="wp-image-163" />
                                            </figure>

                                            <h3 class="wp-block-heading" style="margin-top:16px">Professional</h3>

                                            <p>Tempor ullamcorper urna, est, lectus amet sit tempor pretium mi sed morbi
                                                cras posuere sit ultrices bibendum augue sit ornare.</p>
                                        </div>

                                        <div class="wp-block-column is-layout-flow wp-container-19">
                                            <figure class="wp-block-image size-large">
                                                <img decoding="async"
                                                    src="https://wp-themes.com/wp-content/themes/astra/inc/assets/images/starter-content/support.svg"
                                                    alt="" class="wp-image-164" />
                                            </figure>

                                            <h3 class="wp-block-heading" style="margin-top:16px">Support</h3>

                                            <p>Tempor ullamcorper urna, est, lectus amet sit tempor pretium mi sed morbi
                                                cras posuere sit ultrices bibendum augue sit ornare.</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="wp-block-group alignfull has-background is-layout-constrained wp-container-23"
                                    id="contact"
                                    style="background:linear-gradient(90deg,rgba(6,150,0) 0%,rgba(130,45,255) 64%,rgba(255,15,255) 98%);padding-top:104px;padding-bottom:104px">

                                    <h2 class="has-text-align-center has-text-color wp-block-heading"
                                        style="color:#ffffff">Create a virtual storefront today.!</h2>

                                    <div class="wp-block-buttons alignwide is-horizontal is-content-justification-center is-layout-flex wp-container-22"
                                        style="margin-top:50px">
                                        <div class="wp-block-button">
                                            <a class="wp-block-button__link wp-element-button text-white">Rent a virtual
                                                storefront</a>
                                        </div>
                                    </div>
                                </div>

                                <div class="wp-block-group alignfull has-ast-global-color-4-background-color has-background is-layout-constrained wp-container-16"
                                    id="reviews">
                                    <figure class="wp-block-image aligncenter size-full">
                                        <img decoding="async"
                                            src=""
                                            alt="" class="wp-image-235" />
                                    </figure>

                                    <p class="has-text-align-center" style="font-size:22px;line-height:1.6">“Lorem ipsum
                                        dolor sit amet, consectetur adipisicing elit. Veritatis, minima saepe?
                                        Temporibus aliquam expedita ipsum iure! Eveniet provident reprehenderit tenetur?
                                    </p>

                                    <p class="has-text-align-center">
                                        <strong>Lorem, ipsum.</strong>
                                    </p>
                                </div>

                            </div>
                            <!-- .entry-content .clear -->

                        </article>
                        <!-- #post-## -->


                        <!-- #comments -->
                    </main>
                    <!-- #main -->

                </div>
                <!-- #primary -->

            </div>
            <!-- ast-container -->
        </div>
        <!-- #content -->
        <footer class="site-footer" id="colophon" itemtype="https://schema.org/WPFooter" itemscope="itemscope"
            itemid="#colophon">
            <div class="site-below-footer-wrap ast-builder-grid-row-container site-footer-focus-item ast-builder-grid-row-full ast-builder-grid-row-tablet-full ast-builder-grid-row-mobile-full ast-footer-row-stack ast-footer-row-tablet-stack ast-footer-row-mobile-stack"
                data-section="section-below-footer-builder">
                <div class="ast-builder-grid-row-container-inner">
                    <div class="ast-builder-footer-grid-columns site-below-footer-inner-wrap ast-builder-grid-row">
                        <div class="site-footer-below-section-1 site-footer-section site-footer-section-1">
                            <div class="ast-builder-layout-element ast-flex site-footer-focus-item ast-footer-copyright"
                                data-section="section-footer-builder">
                                <div class="ast-footer-copyright">
                                    <p>
                                        Copyright &copy; 2023 WebMaster | Powered by
                                        <a href="https://www.facebook.com/Zo.FirstTY" rel="nofollow noopener"
                                            target="_blank">KhongLao WebMaster</a>
                                    </p>
                                    <br>
                                    <p>
                                        Update: 12/03/2023
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </footer>
        <!-- #colophon -->
    </div>
    <!-- #page -->


    <script id='astra-theme-js-js-extra'>
        var astra = {
            "break_point": "921",
            "isRtl": "",
            "is_scroll_to_id": "1",
            "is_scroll_to_top": ""
        };
    </script>
    <script src='https://wp-themes.com/wp-content/themes/astra/assets/js/minified/frontend.min.js?ver=4.0.2'
        id='astra-theme-js-js'></script>
    <script>
        /(trident|msie)/i.test(navigator.userAgent) && document.getElementById && window.addEventListener && window.addEventListener("hashchange", function () {
            var t,
                e = location.hash.substring(1);
            /^[A-z0-9_-]+$/.test(e) && (t = document.getElementById(e)) && (/^(?:a|select|input|button|textarea)$/i.test(t.tagName) || (t.tabIndex = -1), t.focus())
        }, !1);
    </script>
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({
                pageLanguage: 'en'
            }, 'google_translate_element');
        }
    </script>

    <script type="text/javascript"
        src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"
        integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"
        integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF"
        crossorigin="anonymous"></script>
</body>

</html>